-- petadoption schema (lean version)
CREATE DATABASE IF NOT EXISTS kaagapal
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE kaagapal;

-- Users
CREATE TABLE IF NOT EXISTS users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  firstname     VARCHAR(255) NOT NULL,
  lastname      VARCHAR(255) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  address       VARCHAR(255) NULL,
  phone         VARCHAR(20) NULL,
  password      VARCHAR(255) NOT NULL,
  role          ENUM('admin','adopter') NOT NULL DEFAULT 'adopter',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role),
  INDEX idx_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pets
CREATE TABLE IF NOT EXISTS pets (
  pet_id       INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(255) NOT NULL,
  type         ENUM('Cat','Dog') NOT NULL,
  breed        VARCHAR(255) NOT NULL,
  age          INT NOT NULL,
  gender       ENUM('Male','Female') NOT NULL,
  description  TEXT NOT NULL,
  image        VARCHAR(255) NOT NULL,
  status       ENUM('Available','Pending','Adopted') NOT NULL DEFAULT 'Available',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pets_status (status),
  INDEX idx_pets_type (type),
  INDEX idx_pets_gender (gender)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Adoptions
CREATE TABLE IF NOT EXISTS adoptions (
  adoption_id       INT AUTO_INCREMENT PRIMARY KEY,
  adopter_id        INT NOT NULL,
  pet_id            INT NOT NULL,
  living_situation  TEXT NOT NULL,
  reason_adoption   TEXT NOT NULL,
  status            ENUM('Pending','Approved','Declined') NOT NULL DEFAULT 'Pending',
  date_applied      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_adoptions_user
    FOREIGN KEY (adopter_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_adoptions_pet
    FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE,

  UNIQUE KEY uq_adopter_pet_once (adopter_id, pet_id),
  INDEX idx_adoptions_status (status),
  INDEX idx_adoptions_adopter (adopter_id),
  INDEX idx_adoptions_pet (pet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional seed (admin): replace HASH before running as raw SQL
-- INSERT INTO users (firstname, lastname, email, password, role)
-- VALUES ('KaagaPal', 'Admin', 'admin@kaagapal.com', '{BCRYPT_HASH}', 'admin')
-- ON DUPLICATE KEY UPDATE email = email;


