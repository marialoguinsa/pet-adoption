<?php
session_start();
require_once __DIR__ . '/db_connection.php';

$loginError = '';
$signupSuccess = '';

// Check for signup success message
if (isset($_SESSION['signup_success'])) {
    $signupSuccess = $_SESSION['signup_success'];
    unset($_SESSION['signup_success']); // Clear it after displaying
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $loginError = 'Please enter a valid email and password.';
    } else {
        $sql = 'SELECT user_id, email, password, role, firstname FROM users WHERE email = ? LIMIT 1';
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = (int)$user['user_id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_name'] = $user['firstname'];

                if ($user['role'] === 'admin') {
                    header('Location: admin/dashboard.php');
                } else {
                    header('Location: adopter/homepage.php');
                }
                exit;
            } else {
                $loginError = 'Invalid email or password.';
            }
        } else {
            $loginError = 'Something went wrong. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>KaagaPal Login</title>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #1E3A4E;

        display: flex;
        justify-content: flex-end; 
        align-items: center;
        height: 100vh;
        position: relative; 
        padding-right: 350px; 
    }
    .logo {
        position: absolute;
        top: 20px; 
        left: 20px; 
        width: 150px; 
        height: auto;
    }

    .login-container {
        background-color: white;
        width: 400px;
        height: 570px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        text-align: center;
        overflow: hidden;
        position: relative;
        right:20%;

    }

    .paw-image img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        display: block;
    }

    .login-content {
        padding: 20px 45px;
        height: 40%;
    }

    input[type="text"], input[type="password"] {
        width: 100%;
        padding: 12px;
        margin: 8px 0;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-sizing: border-box;
        font-size: 14px;
    }

    .login-btn {
        width: 100%;
        padding: 12px;
        background-color: #f08080;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 10px;
    }

    .login-btn:hover {
        background-color: #e06b6b;
    }

    .signup {
        font-size: 14px;
        margin: 15px 0;
    }

    .signup a {
        text-decoration: none;
        color: #f08080;
        font-weight: bold;
    }
    .cont-quote{
        position: relative;
        right: 10%;
        bottom: 5%;
        margin: 0;
        
    }
    .cont-quote .qfirst {
        text-align: left;
        font-size: 45px;
        color: white;
        font-weight: 1000;
        margin: 0;
    }
    .cont-quote .qsec {
        text-align: left;
        font-size: 65px;
        color: white;
        font-weight: 1000;
        margin: 0;
    }
    .header-login{
        margin-top: -20px;
        padding: 20px;
    }
    .header-login h1, p{
        margin: 0;
        font-size: 24px;
        color: #243b55;
        font-weight: 900;
        padding: 0;
    }
    .form-login{
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        
    }
   
</style>
</head>
<body>
    
<img src="pics/whitelogo.png" alt="KaagaPal Logo" class="logo">

    
<div class="login-container">
    <div class="paw-image">
        <img src="pics/loginpett.jpg" alt="paw">
    </div>
     <div class="header-login">
        <h1>Every tail deserves a tale,</h1>
        <p>A Home for Every Paw</p>
        </div>
    <div class="login-content">
       
    <div class="form-login">
        <?php if (!empty($signupSuccess)): ?>
        <div style="color:#2e7d32;background:#e8f5e8;border:1px solid #c8e6c9;padding:12px;border-radius:6px;width:100%;margin-bottom:12px;text-align:center;">
            <strong style="font-size:14px;">✓ <?= htmlspecialchars($signupSuccess) ?></strong>
        </div>
        <?php endif; ?>
        <?php if (!empty($loginError)): ?>
        <div style="color:#b00020;background:#ffebee;border:1px solid #ffcdd2;padding:8px;border-radius:6px;width:100%;margin-bottom:8px;">
            <?= htmlspecialchars($loginError) ?>
        </div>
        <?php endif; ?>
        <form method="post" action="">
        <input type="text" name="email" placeholder="Email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        <input type="password" name="password" placeholder="Password">
        <button class="login-btn" type="submit">Login</button>

        <div class="signup">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </div>

        </form>
    </div>
    </div>
</div>

</body>
</html>

