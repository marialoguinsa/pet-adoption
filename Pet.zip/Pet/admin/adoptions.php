<?php
require_once __DIR__ . '/../auth_check.php';
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../adopter/homepage.php');
    exit;
}
require_once __DIR__ . '/../db_connection.php';

$adoptions = [];
$sql = "SELECT a.adoption_id, a.status, a.date_applied, a.living_situation, a.reason_adoption,
               u.firstname, u.lastname, u.phone, u.address, u.email, 
               p.name AS pet_name, p.type, p.breed, p.age, p.gender
        FROM adoptions a
        JOIN users u ON a.adopter_id = u.user_id
        JOIN pets p ON a.pet_id = p.pet_id
        WHERE a.status IN ('Approved', 'Declined')
        ORDER BY a.date_applied ASC";
$res = $conn->query($sql);
if ($res) { while ($r = $res->fetch_assoc()) { $adoptions[] = $r; } $res->free(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoptions - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Common Admin CSS -->
    <link rel="stylesheet" href="css/admin_common.css">
    <style>
        /* Adoptions Specific Styles */
        tbody tr {
            border-bottom: 1px solid #8B4513;
        }

        .status-cell {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .status-text {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .status-approved {
            color: #4CAF50;
        }

        .status-declined {
            color: #d32f2f;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <img src="../pics/whitelogo.png" alt="KaagaPal Logo">
        
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-paw"></i>
                <span>Dashboard</span>
            </a>
            <a href="pet_details.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Pet Details</span>
            </a>
            <a href="applications.php" class="nav-item">
                <i class="fas fa-file-lines"></i>
                <span>Applications</span>
            </a>
            <a href="adoptions.php" class="nav-item active">
                <i class="fas fa-heart"></i>
                <span>Adoptions</span>
            </a>
            <a href="admin_settings.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                <span>Admin</span>
            </a>
        </nav>

        <div class="logout-section">
            <a href="../logout.php" class="logout-link">
                <i class="fas fa-right-from-bracket"></i>
                <span>Log out</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Banner -->
        <div class="header-banner">
            <h1>Adoptions Tracking</h1>
            <p>View all approved and declined adoption applications.</p>
        </div>

        <!-- Content Container -->
        <div class="content-container">
            <!-- Adoptions Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Pet Name</th>
                            <th>Type</th>
                            <th>Adopter Name</th>
                            <th>Date Applied</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Living</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($adoptions)): ?>
                        <tr><td colspan="10" style="text-align:center;">No adoptions to track yet.</td></tr>
                        <?php else: foreach ($adoptions as $d): 
                            $statusClass = $d['status'] === 'Approved' ? 'status-approved' : 'status-declined';
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($d['pet_name']) ?></td>
                            <td><?= htmlspecialchars($d['type']) ?></td>
                            <td><?= htmlspecialchars($d['firstname'] . ' ' . $d['lastname']) ?></td>
                            <td><?= date('Y-m-d', strtotime($d['date_applied'])) ?></td>
                            <td><?= htmlspecialchars($d['phone']) ?></td>
                            <td><?= htmlspecialchars($d['email']) ?></td>
                            <td><?= htmlspecialchars($d['address']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($d['living_situation'])) ?></td>
                            <td><?= htmlspecialchars(substr($d['reason_adoption'], 0, 30)) ?><?= strlen($d['reason_adoption']) > 30 ? '...' : '' ?></td>
                            <td>
                                <div class="status-cell">
                                    <span class="status-text <?= $statusClass ?>"><?= htmlspecialchars($d['status']) ?></span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Simple JavaScript for navigation highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    // Remove active class from all items
                    navItems.forEach(nav => nav.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>

