<?php
require_once __DIR__ . '/../auth_check.php';
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../adopter/homepage.php');
    exit;
}
require_once __DIR__ . '/../db_connection.php';

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $adoption_id = (int)($_POST['adoption_id'] ?? 0);
    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE adoptions a JOIN pets p ON a.pet_id=p.pet_id SET a.status='Approved', p.status='Adopted' WHERE a.adoption_id=?");
        if ($stmt) { $stmt->bind_param('i', $adoption_id); $stmt->execute(); $stmt->close(); $flash = 'Application approved.'; }
    } elseif ($action === 'decline') {
        // First, get the pet_id before declining
        $getPetStmt = $conn->prepare("SELECT pet_id FROM adoptions WHERE adoption_id = ?");
        if ($getPetStmt) {
            $getPetStmt->bind_param('i', $adoption_id);
            $getPetStmt->execute();
            $petResult = $getPetStmt->get_result();
            $adoptionData = $petResult->fetch_assoc();
            $getPetStmt->close();
            
            if ($adoptionData) {
                $pet_id = $adoptionData['pet_id'];
                
                // Update adoption status to Declined
                $stmt = $conn->prepare("UPDATE adoptions SET status='Declined' WHERE adoption_id=?");
                if ($stmt) {
                    $stmt->bind_param('i', $adoption_id);
                    $stmt->execute();
                    $stmt->close();
                    
                    // Check if there are any other pending applications for this pet
                    $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM adoptions WHERE pet_id = ? AND status = 'Pending'");
                    if ($countStmt) {
                        $countStmt->bind_param('i', $pet_id);
                        $countStmt->execute();
                        $countResult = $countStmt->get_result();
                        $count = $countResult->fetch_assoc()['count'];
                        $countStmt->close();
                        
                        // If no pending applications, set pet status back to Available
                        if ($count == 0) {
                            $updateStmt = $conn->prepare("UPDATE pets SET status = 'Available' WHERE pet_id = ? AND status = 'Pending'");
                            if ($updateStmt) {
                                $updateStmt->bind_param('i', $pet_id);
                                $updateStmt->execute();
                                $updateStmt->close();
                            }
                        }
                    }
                    
                    $flash = 'Application declined.';
                }
            }
        }
    }
}

$apps = [];
$sql = "SELECT a.adoption_id, a.status, a.date_applied, a.living_situation, a.reason_adoption,
               u.firstname, u.lastname, u.phone, u.email, u.address,
               p.name AS pet_name, p.type, p.breed, p.age, p.gender
        FROM adoptions a
        JOIN users u ON a.adopter_id = u.user_id
        JOIN pets p ON a.pet_id = p.pet_id
        WHERE a.status = 'Pending'
        ORDER BY a.date_applied ASC";
$res = $conn->query($sql);
if ($res) { while ($r = $res->fetch_assoc()) { $apps[] = $r; } $res->free(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applications - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Common Admin CSS -->
    <link rel="stylesheet" href="css/admin_common.css">
    <style>
        /* Applications Specific Styles */
        .status-cell {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .status-text {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
        }

        .status-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-accept {
            background-color: #F27274;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-block;
        }

        .btn-accept:hover {
            background-color: #592518;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(139, 69, 19, 0.3);
        }

        .btn-decline {
            background-color: #D9D9D9;
            color: #264962;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-decline:hover {
            background-color:rgb(255, 255, 255);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(211, 47, 47, 0.3);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <img src="../pics/whitelogo.png" alt="KaagaPal Logo">
            
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-paw"></i>
                <span>Dashboard</span>
            </a>
            <a href="pet_details.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Pet Details</span>
            </a>
            <a href="applications.php" class="nav-item active">
                <i class="fas fa-file-lines"></i>
                <span>Applications</span>
            </a>
            <a href="adoptions.php" class="nav-item">
                <i class="fas fa-heart"></i>
                <span>Adoptions</span>
            </a>
            <a href="admin_settings.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                <span>Admin</span>
            </a>
        </nav>

        <div class="logout-section">
            <a href="../logout.php" class="logout-link">
                <i class="fas fa-right-from-bracket"></i>
                <span>Log out</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Banner -->
        <div class="header-banner">
            <h1>Review Applications</h1>
            <p>Approve or decline adoption requests.</p>
        </div>

        <!-- Content Container -->
        <div class="content-container">
            <?php if ($flash): ?>
            <div style="background:#e8f5e8;color:#2e7d32;border:1px solid #c8e6c9;padding:10px;border-radius:6px;margin-bottom:10px;">
                <?= htmlspecialchars($flash) ?>
            </div>
            <?php endif; ?>
            <!-- Applications Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Pet Name</th>
                            <th>Type</th>
                            <th>Adopter Name</th>
                            <th>Date Applied</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Living</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($apps)): ?>
                        <tr><td colspan="9" style="text-align:center;">No pending applications.</td></tr>
                        <?php else: foreach ($apps as $a): ?>
                        <tr>
                            <td><?= htmlspecialchars($a['pet_name']) ?></td>
                            <td><?= htmlspecialchars($a['type']) ?></td>
                            <td><?= htmlspecialchars($a['firstname'] . ' ' . $a['lastname']) ?></td>
                            <td><?= date('Y-m-d', strtotime($a['date_applied'])) ?></td>
                            <td><?= htmlspecialchars($a['phone']) ?></td>
                            <td><?= htmlspecialchars($a['email']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($a['living_situation'])) ?></td>
                            <td><?= htmlspecialchars(substr($a['reason_adoption'], 0, 30)) ?><?= strlen($a['reason_adoption']) > 30 ? '...' : '' ?></td>
                            <td>
                                <div class="status-cell">
                                    <span class="status-text"><?= htmlspecialchars($a['status']) ?></span>
                                    <div class="status-buttons">
                                        <form method="post" action="" style="display:inline;">
                                            <input type="hidden" name="adoption_id" value="<?= (int)$a['adoption_id'] ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button class="btn-accept" type="submit">ACCEPT</button>
                                        </form>
                                        <form method="post" action="" style="display:inline;">
                                            <input type="hidden" name="adoption_id" value="<?= (int)$a['adoption_id'] ?>">
                                            <input type="hidden" name="action" value="decline">
                                            <button class="btn-decline" type="submit">DECLINE</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Simple JavaScript for navigation highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    // Remove active class from all items
                    navItems.forEach(nav => nav.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });

        // Buttons now submit forms; no extra JS needed.
    </script>
</body>
</html>

