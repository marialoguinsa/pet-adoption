<?php
require_once __DIR__ . '/../auth_check.php';
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../adopter/homepage.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Common Admin CSS -->
    <link rel="stylesheet" href="css/admin_common.css">
    <style>
        /* Admin Settings Specific Styles */
        /* Settings Box */
        .settings-box {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }

        .form-row {
            display: flex;
            gap: 30px;
            margin-bottom: 25px;
        }

        .form-group {
            flex: 1;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            color: #333;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: white;
        }

        .form-group input:focus {
            outline: none;
            border-color: #1E3A4E;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <img src="../pics/whitelogo.png" alt="KaagaPal Logo">
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-paw"></i>
                <span>Dashboard</span>
            </a>
            <a href="pet_details.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Pet Details</span>
            </a>
            <a href="applications.php" class="nav-item">
                <i class="fas fa-file-lines"></i>
                <span>Applications</span>
            </a>
            <a href="adoptions.php" class="nav-item">
                <i class="fas fa-heart"></i>
                <span>Adoptions</span>
            </a>
            </a>
            <a href="admin_settings.php" class="nav-item active">
                <i class="fas fa-user-shield"></i>
                <span>Admin</span>
            </a>
        </nav>

        <div class="logout-section">
            <a href="../logout.php" class="logout-link">
                <i class="fas fa-right-from-bracket"></i>
                <span>Log out</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Banner -->
        <div class="header-banner">
            <h1>Admin Settings</h1>
            <p>Manage admin account and user roles.</p>
        </div>

        <!-- Content Container -->
        <div class="content-container">
            <!-- Settings Box -->
            <div class="settings-box">
                <div class="form-row">
                    <div class="form-group">
                        <label for="adminName">Admin Name:</label>
                        <input type="text" id="adminName" name="adminName" value="KaagaPal">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="admin@kaagapal.com">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Simple JavaScript for navigation highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    // Remove active class from all items
                    navItems.forEach(nav => nav.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>

