<?php
require_once __DIR__ . '/../auth_check.php';
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../adopter/homepage.php');
    exit;
}
require_once __DIR__ . '/../db_connection.php';

// Function to handle image upload
function handleImageUpload($fileInput, $existingImage = '') {
    // If no file is uploaded and existing image is provided, keep existing
    if (!isset($_FILES[$fileInput]) || $_FILES[$fileInput]['error'] === UPLOAD_ERR_NO_FILE) {
        return $existingImage ?: 'pics/pets.jpg';
    }
    
    // Check for upload errors
    if ($_FILES[$fileInput]['error'] !== UPLOAD_ERR_OK) {
        return $existingImage ?: 'pics/pets.jpg';
    }
    
    $uploadDir = __DIR__ . '/../pics/';
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    $file = $_FILES[$fileInput];
    
    // Validate file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        return $existingImage ?: 'pics/pets.jpg';
    }
    
    // Validate file size
    if ($file['size'] > $maxSize) {
        return $existingImage ?: 'pics/pets.jpg';
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'pet_' . time() . '_' . uniqid() . '.' . $extension;
    $targetPath = $uploadDir . $filename;
    
    // Create pics directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        // Delete old image if it exists and is not the default
        if ($existingImage && $existingImage !== 'pics/pets.jpg' && $existingImage !== 'pics/placeholder.jpg') {
            $oldPath = __DIR__ . '/../' . $existingImage;
            if (file_exists($oldPath) && is_file($oldPath)) {
                @unlink($oldPath);
            }
        }
        return 'pics/' . $filename;
    }
    
    return $existingImage ?: 'pics/pets.jpg';
}

// Basic CRUD handlers
$flashMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $breed = trim($_POST['breed'] ?? '');
        $age = (int)($_POST['age'] ?? 0);
        $type = $_POST['type'] ?? '';
        $gender = $_POST['gender'] ?? '';
        $description = trim($_POST['description'] ?? '');
        $image = handleImageUpload('petImage');
        $status = 'Available';

        $stmt = $conn->prepare('INSERT INTO pets (name, type, breed, age, gender, description, image, status) VALUES (?,?,?,?,?,?,?,?)');
        if ($stmt) {
            $stmt->bind_param('ssssssss', $name, $type, $breed, $age, $gender, $description, $image, $status);
            if ($stmt->execute()) { $flashMessage = 'Pet added.'; }
            $stmt->close();
        }
    } elseif ($action === 'update') {
        $pet_id = (int)($_POST['pet_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $breed = trim($_POST['breed'] ?? '');
        $age = (int)($_POST['age'] ?? 0);
        $type = $_POST['type'] ?? '';
        $gender = $_POST['gender'] ?? '';
        $description = trim($_POST['description'] ?? '');
        $status = $_POST['status'] ?? 'Available';
        
        // Get existing image path
        $existingImage = '';
        $getStmt = $conn->prepare('SELECT image FROM pets WHERE pet_id=?');
        if ($getStmt) {
            $getStmt->bind_param('i', $pet_id);
            $getStmt->execute();
            $result = $getStmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $existingImage = $row['image'] ?? '';
            }
            $getStmt->close();
        }
        
        $image = handleImageUpload('petImage', $existingImage);
        
        $stmt = $conn->prepare('UPDATE pets SET name=?, type=?, breed=?, age=?, gender=?, description=?, image=?, status=? WHERE pet_id=?');
        if ($stmt) {
            $stmt->bind_param('ssssssssi', $name, $type, $breed, $age, $gender, $description, $image, $status, $pet_id);
            if ($stmt->execute()) { $flashMessage = 'Pet updated.'; }
            $stmt->close();
        }
    } elseif ($action === 'delete') {
        $pet_id = (int)($_POST['pet_id'] ?? 0);
        
        // Get image path before deleting
        $getStmt = $conn->prepare('SELECT image FROM pets WHERE pet_id=?');
        if ($getStmt) {
            $getStmt->bind_param('i', $pet_id);
            $getStmt->execute();
            $result = $getStmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $imagePath = $row['image'] ?? '';
                // Delete image file if it exists and is not default
                if ($imagePath && $imagePath !== 'pics/pets.jpg' && $imagePath !== 'pics/placeholder.jpg') {
                    $filePath = __DIR__ . '/../' . $imagePath;
                    if (file_exists($filePath) && is_file($filePath)) {
                        @unlink($filePath);
                    }
                }
            }
            $getStmt->close();
        }
        
        $stmt = $conn->prepare('DELETE FROM pets WHERE pet_id=?');
        if ($stmt) { $stmt->bind_param('i', $pet_id); $stmt->execute(); $stmt->close(); $flashMessage = 'Pet removed.'; }
    }
}

// Get filter parameters
$searchTerm = $_GET['search'] ?? '';
$typeFilter = $_GET['type'] ?? 'all';
$statusFilter = $_GET['status'] ?? 'all';

// Build query with filters
$sql = "SELECT pet_id, name, type, breed, age, gender, status, image, description FROM pets WHERE 1=1";
$params = [];
$types = '';

// Search filter (searches in name and breed)
if (!empty($searchTerm)) {
    $sql .= " AND (name LIKE ? OR breed LIKE ?)";
    $searchPattern = '%' . $searchTerm . '%';
    $params[] = $searchPattern;
    $params[] = $searchPattern;
    $types .= 'ss';
}

// Type filter
if ($typeFilter && strtolower($typeFilter) !== 'all') {
    $sql .= " AND type = ?";
    $params[] = ucfirst(strtolower($typeFilter));
    $types .= 's';
}

// Status filter
if ($statusFilter && strtolower($statusFilter) !== 'all') {
    $sql .= " AND status = ?";
    $params[] = ucfirst(strtolower($statusFilter));
    $types .= 's';
}

$sql .= " ORDER BY pet_id ASC";

// Load pets list
$pets = [];
$stmt = $conn->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $pets[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Details - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Common Admin CSS -->
    <link rel="stylesheet" href="css/admin_common.css">
    <style>
        /* Pet Details Specific Styles */
        .main-content {
            position: relative;
        }

        .content-container {
            padding-bottom: 100px;
        }

        /* Search and Filter Section */
        .search-filter-section {
            background-color: #F5F5F5;
            padding: 20px 0;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .search-filter-section label {
            font-size: 14px;
            color: #333;
            font-weight: normal;
        }

        .search-filter-section input[type="text"] {
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            width: 200px;
        }

        .search-filter-section select {
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            background-color: white;
            cursor: pointer;
            width: 150px;
        }

        .btn-search, .btn-refresh {
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            background-color: #622B26;
            color: white;
            transition: background-color 0.3s;
        }

        .btn-search:hover, .btn-refresh:hover {
            background-color: #654321;
        }

        .btn-refresh {
            margin-left: auto;
        }

        /* Pet Details Table Specific Styles */
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tbody tr:nth-child(odd) {
            background-color: white;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-edit {
            background-color: #F27274;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-block;
        }

        .btn-edit:hover {
            background-color: #592518;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(139, 69, 19, 0.3);
        }

        .btn-remove {
            background-color: #D9D9D9;
            color: #264962;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-remove:hover {
            background-color:rgb(255, 255, 255);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(211, 47, 47, 0.3);
        }

        /* Floating Add Pet Button */
        .add-pet-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 15px 25px;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
            z-index: 1000;
        }

        .add-pet-btn:hover {
            background-color: #1976D2;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        .add-pet-btn i {
            font-size: 18px;
        }

        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal-container {
            background-color: #FFE5E5;
            border-radius: 15px;
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            position: relative;
            padding: 30px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin-bottom: 25px;
            text-align: center;
        }

        .modal-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group-full {
            grid-column: 1 / -1;
        }

        .form-group label {
            font-size: 14px;
            color: #333;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select,
        .form-group textarea {
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: white;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #8B4513;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .file-upload-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .file-upload-group input[type="file"] {
            display: none;
        }

        .file-upload-btn {
            padding: 8px 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: white;
            color: #333;
            cursor: pointer;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s;
        }

        .file-upload-btn:hover {
            background-color: #f5f5f5;
            border-color: #8B4513;
        }

        .file-name {
            font-size: 13px;
            color: #666;
        }

        .modal-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .btn-save,
        .btn-add {
            background-color: #8B4513;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-save:hover,
        .btn-add:hover {
            background-color: #654321;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(139, 69, 19, 0.3);
        }

        .btn-cancel-modal {
            background-color: transparent;
            color: #dc3545;
            border: none;
            padding: 10px 30px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-cancel-modal:hover {
            color: #c82333;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <img src="../pics/whitelogo.png" alt="KaagaPal Logo">
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-paw"></i>
                <span>Dashboard</span>
            </a>
            <a href="pet_details.php" class="nav-item active">
                <i class="fas fa-clipboard-list"></i>
                <span>Pet Details</span>
            </a>
            <a href="applications.php" class="nav-item">
                <i class="fas fa-file-lines"></i>
                <span>Applications</span>
            </a>
            <a href="adoptions.php" class="nav-item">
                <i class="fas fa-heart"></i>
                <span>Adoptions</span>
            </a>
            <a href="admin_settings.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                <span>Admin</span>
            </a>
        </nav>

        <div class="logout-section">
            <a href="../logout.php" class="logout-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Log out</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Banner -->
        <div class="header-banner">
            <h1>Pet Details</h1>
            <p>Manage pets - create, update or remove pet records.</p>
        </div>

        <!-- Content Container -->
        <div class="content-container">
            <!-- Search and Filter Section -->
            <div class="search-filter-section">
                <label for="search">Search:</label>
                <input type="text" id="search" name="search" placeholder="Search a pet..." value="<?= htmlspecialchars($searchTerm) ?>">
                <button type="button" class="btn-search">Search</button>
                
                <label for="type">Type:</label>
                <select id="type" name="type">
                    <option value="all" <?= ($typeFilter === 'all' || $typeFilter === '') ? 'selected' : '' ?>>All</option>
                    <option value="dog" <?= (strtolower($typeFilter) === 'dog') ? 'selected' : '' ?>>Dog</option>
                    <option value="cat" <?= (strtolower($typeFilter) === 'cat') ? 'selected' : '' ?>>Cat</option>
                </select>
                
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="all" <?= ($statusFilter === 'all' || $statusFilter === '') ? 'selected' : '' ?>>All</option>
                    <option value="available" <?= (strtolower($statusFilter) === 'available') ? 'selected' : '' ?>>Available</option>
                    <option value="adopted" <?= (strtolower($statusFilter) === 'adopted') ? 'selected' : '' ?>>Adopted</option>
                    <option value="pending" <?= (strtolower($statusFilter) === 'pending') ? 'selected' : '' ?>>Pending</option>
                </select>
                
                <button type="button" class="btn-refresh">Refresh</button>
            </div>

            <!-- Flash -->
            <?php if (!empty($flashMessage)): ?>
            <div style="background:#e8f5e8;color:#2e7d32;border:1px solid #c8e6c9;padding:10px;border-radius:6px;margin-bottom:10px;">
                <?= htmlspecialchars($flashMessage) ?>
            </div>
            <?php endif; ?>

            <!-- Pet Records Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Pet ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Breed</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pets)): ?>
                        <tr><td colspan="8" style="text-align:center;">No pets found.</td></tr>
                        <?php else: foreach ($pets as $p): ?>
                        <tr>
                            <td><?= (int)$p['pet_id'] ?></td>
                            <td><?= htmlspecialchars($p['name']) ?></td>
                            <td><?= htmlspecialchars($p['type']) ?></td>
                            <td><?= htmlspecialchars($p['breed']) ?></td>
                            <td><?= (int)$p['age'] ?></td>
                            <td><?= htmlspecialchars($p['gender']) ?></td>
                            <td><?= htmlspecialchars($p['status']) ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-edit" onclick="editPet('<?= (int)$p['pet_id'] ?>','<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['breed'], ENT_QUOTES) ?>','<?= (int)$p['age'] ?>','<?= htmlspecialchars($p['type'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['gender'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['description'] ?? '', ENT_QUOTES) ?>', '<?= htmlspecialchars($p['status'], ENT_QUOTES) ?>', '<?= htmlspecialchars($p['image'] ?? '', ENT_QUOTES) ?>')">Edit</button>
                                    <form method="post" action="" style="display:inline;" onsubmit="return confirm('Remove this pet?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="pet_id" value="<?= (int)$p['pet_id'] ?>">
                                        <button class="btn-remove" type="submit">Remove</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Floating Add Pet Button -->
    <button class="add-pet-btn" onclick="openAddPetModal()">
        <i class="fas fa-paw"></i>
        <i class="fas fa-plus"></i>
        <span>Add Pet</span>
    </button>

    <!-- Modal -->
    <div class="modal-overlay" id="petModal">
        <div class="modal-container">
            <h2 class="modal-title" id="modalTitle">Add Pet</h2>
            <form class="modal-form" id="petForm" method="post" enctype="multipart/form-data" onsubmit="handleSubmit(event)">
                <div class="form-group form-group-full">
                    <label for="petName">Name:</label>
                    <input type="text" id="petName" name="name" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="petBreed">Breed:</label>
                        <input type="text" id="petBreed" name="breed" required>
                    </div>
                    <div class="form-group">
                        <label for="petAge">Age:</label>
                        <input type="number" id="petAge" name="age" min="0" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="petType">Type:</label>
                        <select id="petType" name="type" required>
                            <option value="">All</option>
                            <option value="Dog">Dog</option>
                            <option value="Cat">Cat</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="petGender">Gender:</label>
                        <select id="petGender" name="gender" required>
                            <option value="">All</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                </div>

                <div class="form-group form-group-full">
                    <label for="petDescription">Description:</label>
                    <textarea id="petDescription" name="description" placeholder="Enter here..." required></textarea>
                </div>

                <div class="form-group form-group-full">
                    <label for="petImage">Pet Image:</label>
                    <div class="file-upload-group">
                        <input type="file" id="petImage" name="petImage" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
                        <label for="petImage" class="file-upload-btn">
                            <i class="fas fa-upload"></i> Choose Image
                        </label>
                        <span class="file-name" id="fileName">No file chosen</span>
                    </div>
                    <div id="imagePreview" style="margin-top: 10px; display: none;">
                        <img id="previewImg" src="" alt="Preview" style="max-width: 200px; max-height: 200px; border-radius: 8px; border: 1px solid #ccc;">
                    </div>
                    <small style="font-size: 12px; color: #666; display: block; margin-top: 5px;">
                        Upload a pet image (JPEG, PNG, GIF, or WebP, max 5MB). If no image is uploaded, the default image will be used.
                    </small>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel-modal" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-add" id="submitBtn">Add</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let isEditMode = false;
        let currentPetId = '';

        // Open Add Pet Modal
        function openAddPetModal() {
            isEditMode = false;
            currentPetId = '';
            document.getElementById('modalTitle').textContent = 'Add Pet';
            document.getElementById('submitBtn').textContent = 'Add';
            document.getElementById('submitBtn').classList.remove('btn-save');
            document.getElementById('submitBtn').classList.add('btn-add');
            document.getElementById('petForm').reset();
            document.getElementById('fileName').textContent = 'No file chosen';
            document.getElementById('imagePreview').style.display = 'none';
            document.getElementById('petModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Edit Pet function
        function editPet(petId, name, breed, age, type, gender, description, status, imagePath) {
            isEditMode = true;
            currentPetId = petId;
            document.getElementById('modalTitle').textContent = 'Edit Pet';
            document.getElementById('submitBtn').textContent = 'Save';
            document.getElementById('submitBtn').classList.remove('btn-add');
            document.getElementById('submitBtn').classList.add('btn-save');
            
            // Populate form fields
            document.getElementById('petName').value = name;
            document.getElementById('petBreed').value = breed;
            document.getElementById('petAge').value = age;
            document.getElementById('petType').value = type;
            document.getElementById('petGender').value = gender;
            document.getElementById('petDescription').value = description;
            
            // Show existing image if available
            if (imagePath && imagePath !== 'pics/pets.jpg' && imagePath !== 'pics/placeholder.jpg') {
                document.getElementById('previewImg').src = '../' + imagePath;
                document.getElementById('imagePreview').style.display = 'block';
            } else {
                document.getElementById('imagePreview').style.display = 'none';
            }
            document.getElementById('fileName').textContent = 'No file chosen (existing image will be kept)';
            
            document.getElementById('petModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Close Modal function
        function closeModal() {
            document.getElementById('petModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        // Close modal when clicking outside
        document.getElementById('petModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // File upload handling
        document.getElementById('petImage').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('fileName').textContent = file.name;
                
                // Show preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('previewImg').src = e.target.result;
                    document.getElementById('imagePreview').style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                document.getElementById('fileName').textContent = 'No file chosen';
                document.getElementById('imagePreview').style.display = 'none';
            }
        });

        // Handle form submit
        function handleSubmit(event) {
            event.preventDefault();
            
            // Add hidden fields for action and pet_id if needed
            const form = document.getElementById('petForm');
            
            // Remove any existing hidden action/pet_id fields
            const existingAction = form.querySelector('input[name="action"]');
            const existingPetId = form.querySelector('input[name="pet_id"]');
            const existingStatus = form.querySelector('input[name="status"]');
            if (existingAction) existingAction.remove();
            if (existingPetId) existingPetId.remove();
            if (existingStatus) existingStatus.remove();
            
            // Add action field
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = isEditMode ? 'update' : 'create';
            form.appendChild(actionInput);
            
            // Add pet_id if in edit mode
            if (isEditMode) {
                const petIdInput = document.createElement('input');
                petIdInput.type = 'hidden';
                petIdInput.name = 'pet_id';
                petIdInput.value = currentPetId;
                form.appendChild(petIdInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'Available';
                form.appendChild(statusInput);
            }
            
            // Submit the form
            form.submit();
        }

        // Add Pet function (for backward compatibility)
        function addPet() {
            openAddPetModal();
        }

        // Function to apply all filters
        function applyFilters() {
            const searchTerm = document.getElementById('search').value.trim();
            const typeFilter = document.getElementById('type').value;
            const statusFilter = document.getElementById('status').value;
            
            const params = new URLSearchParams();
            
            if (searchTerm) {
                params.set('search', searchTerm);
            }
            
            if (typeFilter && typeFilter !== 'all') {
                params.set('type', typeFilter);
            }
            
            if (statusFilter && statusFilter !== 'all') {
                params.set('status', statusFilter);
            }
            
            // Navigate with filters
            window.location.href = 'pet_details.php?' + params.toString();
        }

        // Search functionality
        document.querySelector('.btn-search').addEventListener('click', function() {
            applyFilters();
        });

        // Allow Enter key to trigger search
        document.getElementById('search').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyFilters();
            }
        });

        // Refresh functionality - clears all filters
        document.querySelector('.btn-refresh').addEventListener('click', function() {
            window.location.href = 'pet_details.php';
        });

        // Filter functionality - auto-apply on change
        document.getElementById('type').addEventListener('change', function() {
            applyFilters();
        });

        document.getElementById('status').addEventListener('change', function() {
            applyFilters();
        });

        // Simple JavaScript for navigation highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    // Remove active class from all items
                    navItems.forEach(nav => nav.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>

