<?php
require_once __DIR__ . '/../auth_check.php';
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../adopter/homepage.php');
    exit;
}
require_once __DIR__ . '/../db_connection.php';

// Live counts
$totalPets = 0; $totalAdoptions = 0; $pendingAdoptions = 0; $adminCount = 0;
if ($res = $conn->query('SELECT COUNT(*) AS c FROM pets')) { $totalPets = (int)$res->fetch_assoc()['c']; $res->free(); }
if ($res = $conn->query("SELECT COUNT(*) AS c FROM adoptions WHERE status='Approved'")) { $totalAdoptions = (int)$res->fetch_assoc()['c']; $res->free(); }
if ($res = $conn->query("SELECT COUNT(*) AS c FROM adoptions WHERE status='Pending'")) { $pendingAdoptions = (int)$res->fetch_assoc()['c']; $res->free(); }
if ($res = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='admin'")) { $adminCount = (int)$res->fetch_assoc()['c']; $res->free(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Common Admin CSS -->
    <link rel="stylesheet" href="css/admin_common.css">
    <style>
        /* Dashboard Specific Styles */
        .header-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .welcome-text {
            font-size: 16px;
            color: white;
        }

        .admin-count {
            font-size: 14px;
            color: white;
        }

        /* Statistics Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .stat-card h3 {
            font-size: 16px;
            color: #666;
            margin-bottom: 10px;
            font-weight: normal;
        }

        .stat-card .stat-number {
            font-size: 36px;
            color: #1E3A4E;
            font-weight: bold;
        }

        /* Recent Activity Section */
        .activity-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .activity-header {
            background-color: #1E3A4E;
            padding: 20px 25px;
            border-radius: 10px 10px 0 0;
        }

        .activity-header h2 {
            color: white;
            font-size: 20px;
            font-weight: bold;
        }

        .activity-content {
            padding: 25px;
            background-color: white;
        }

        .activity-list {
            list-style: none;
        }

        .activity-list li {
            color: #333;
            padding: 12px 0;
            padding-left: 35px;
            position: relative;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .activity-list li:not(:last-child) {
            border-bottom: 1px solid #e0e0e0;
        }

        .activity-list li i {
            position: absolute;
            left: 0;
            font-size: 16px;
        }

        .activity-list li .fa-check {
            color: #4CAF50;
        }

        .activity-list li .fa-pencil {
            color: #2196F3;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <img src="../pics/whitelogo.png" alt="KaagaPal Logo">
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item active">
                <i class="fas fa-paw"></i>
                <span>Dashboard</span>
            </a>
            <a href="pet_details.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Pet Details</span>
            </a>
            <a href="applications.php" class="nav-item">
                <i class="fas fa-file-lines"></i>
                <span>Applications</span>
            </a>
            <a href="adoptions.php" class="nav-item">
                <i class="fas fa-heart"></i>
                <span>Adoptions</span>
            </a>
            <a href="admin_settings.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                <span>Admin</span>
            </a>
        </nav>

        <div class="logout-section">
            <a href="../logout.php" class="logout-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Log out</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Banner -->
        <div class="header-banner">
            <h1>Dashboard</h1>
            <div class="header-info">
                <p class="welcome-text">Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>!</p>
                <p class="admin-count">Admins: <?= $adminCount ?></p>
            </div>
        </div>

        <!-- Content Container -->
        <div class="content-container">
            <!-- Statistics Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Pets:</h3>
                    <div class="stat-number"><?= $totalPets ?></div>
                </div>
                <div class="stat-card">
                    <h3>Adoptions:</h3>
                    <div class="stat-number"><?= $totalAdoptions ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending Adoptions:</h3>
                    <div class="stat-number"><?= $pendingAdoptions ?></div>
                </div>
            </div>

            <!-- Recent Activity Section -->
            <div class="activity-container">
                <div class="activity-header">
                    <h2>Recent Activity:</h2>
                </div>
                <div class="activity-content">
                    <ul class="activity-list">
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Adoption Approved</span>
                        </li>
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Adoption Approved</span>
                        </li>
                        <li>
                            <i class="fas fa-pencil"></i>
                            <span>New Application Submitted</span>
                        </li>
                        <li>
                            <i class="fas fa-pencil"></i>
                            <span>New Application Submitted</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Simple JavaScript for navigation highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    // Remove active class from all items
                    navItems.forEach(nav => nav.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
