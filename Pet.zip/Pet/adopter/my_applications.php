<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

$user_id = $_SESSION['user_id'];
$applications = [];
$flash = '';

// Handle cancel action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel') {
    $adoption_id = (int)($_POST['adoption_id'] ?? 0);
    
    if ($adoption_id > 0) {
        // Verify the adoption belongs to the current user and status is Pending
        $checkStmt = $conn->prepare("SELECT adoption_id, status, pet_id FROM adoptions WHERE adoption_id = ? AND adopter_id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param('ii', $adoption_id, $user_id);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            $adoption = $checkResult->fetch_assoc();
            $checkStmt->close();
            
            if ($adoption && $adoption['status'] === 'Pending') {
                // Delete the adoption application
                $deleteStmt = $conn->prepare("DELETE FROM adoptions WHERE adoption_id = ? AND adopter_id = ?");
                if ($deleteStmt) {
                    $deleteStmt->bind_param('ii', $adoption_id, $user_id);
                    if ($deleteStmt->execute()) {
                        // Update pet status back to Available if no other pending applications
                        $pet_id = $adoption['pet_id'];
                        $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM adoptions WHERE pet_id = ? AND status = 'Pending'");
                        if ($countStmt) {
                            $countStmt->bind_param('i', $pet_id);
                            $countStmt->execute();
                            $countResult = $countStmt->get_result();
                            $count = $countResult->fetch_assoc()['count'];
                            $countStmt->close();
                            
                            if ($count == 0) {
                                $updateStmt = $conn->prepare("UPDATE pets SET status = 'Available' WHERE pet_id = ? AND status = 'Pending'");
                                if ($updateStmt) {
                                    $updateStmt->bind_param('i', $pet_id);
                                    $updateStmt->execute();
                                    $updateStmt->close();
                                }
                            }
                        }
                        $flash = 'Application cancelled successfully.';
                    } else {
                        $flash = 'Failed to cancel application. Please try again.';
                    }
                    $deleteStmt->close();
                }
            } else {
                $flash = 'You can only cancel pending applications.';
            }
        }
    }
}

$sql = "SELECT a.adoption_id, a.status, a.date_applied, a.living_situation, a.reason_adoption,
               p.pet_id, p.name AS pet_name, p.type, p.breed, p.age, p.gender, p.image
        FROM adoptions a
        JOIN pets p ON a.pet_id = p.pet_id
        WHERE a.adopter_id = ?
        ORDER BY a.date_applied ASC";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .nav-menu a.active {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Separator Line */
        .separator {
            height: 2px;
            background-color: #592518;
            width: 100%;
            margin: 0;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Page Title */
        .page-title {
            text-align: center;
            font-size: 36px;
            font-weight: 700;
            color: #1E3A4E;
            margin-bottom: 40px;
            margin-top: 30px;
        }

        /* Table Container */
        .table-container {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background-color: #1E3A4E;
            color: white;
        }

        thead th {
            padding: 15px;
            text-align: left;
            font-size: 14px;
            font-weight: 700;
        }

        tbody tr {
            border-bottom: 1px solid #592518;
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        tbody td {
            padding: 15px;
            font-size: 14px;
            color: #333;
            background-color: white;
        }

        .status-pending {
            color: #f08080;
            font-weight: 600;
        }

        .status-approved {
            color: #4CAF50;
            font-weight: 600;
        }

        .status-declined {
            color: #d32f2f;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .btn-edit {
            background-color: #F27274;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-block;
        }

        .btn-edit:hover {
            background-color: #592518;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(139, 69, 19, 0.3);
        }

        .btn-cancel {
            background-color: #D9D9D9;
            color: #264962;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-cancel:hover {
            background-color:rgb(255, 255, 255);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(211, 47, 47, 0.3);
        }

        .btn-view-details {
            background-color: #592518;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-view-details:hover {
            background-color: #592518;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(139, 69, 19, 0.3);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .page-title {
                font-size: 28px;
            }

            table {
                font-size: 12px;
            }

            thead th,
            tbody td {
                padding: 10px 8px;
            }

            .btn-edit, .btn-cancel {
                padding: 6px 15px;
                font-size: 12px;
            }

            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php" class="active">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>


    <!-- Main Content -->
    <main class="main-content">
        <!-- Page Title -->
        <h1 class="page-title">My Applications</h1>

        <?php if ($flash): ?>
        <div style="background:<?= strpos($flash, 'successfully') !== false ? '#e8f5e8' : '#ffebee' ?>;color:<?= strpos($flash, 'successfully') !== false ? '#2e7d32' : '#c62828' ?>;border:1px solid <?= strpos($flash, 'successfully') !== false ? '#c8e6c9' : '#ffcdd2' ?>;padding:15px;border-radius:8px;margin-bottom:20px;text-align:center;">
            <?= htmlspecialchars($flash) ?>
        </div>
        <?php endif; ?>

        <!-- Applications Table -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Pet Name</th>
                        <th>Type</th>
                        <th>Living</th>
                        <th>Reason</th>
                        <th>Adoption Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: #666;">
                            <p style="font-size: 16px;">You haven't submitted any adoption applications yet.</p>
                            <a href="pets.php" style="display: inline-block; margin-top: 15px; color: #f08080; font-weight: 600;">Browse Pets</a>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($applications as $app): 
                            $statusClass = $app['status'] === 'Approved' ? 'status-approved' : ($app['status'] === 'Declined' ? 'status-declined' : 'status-pending');
                            $dateFormatted = date('Y-m-d', strtotime($app['date_applied']));
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($app['pet_name']) ?></td>
                            <td><?= htmlspecialchars($app['type']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($app['living_situation'])) ?></td>
                            <td><?= htmlspecialchars(substr($app['reason_adoption'], 0, 50)) ?><?= strlen($app['reason_adoption']) > 50 ? '...' : '' ?></td>
                            <td><?= $dateFormatted ?></td>
                            <td>
                                <span class="<?= $statusClass ?>"><?= htmlspecialchars($app['status']) ?></span>
                            </td>
                            <td>
                                <?php if ($app['status'] === 'Pending'): ?>
                                    <div class="action-buttons">
                                        <a href="edit_application.php?adoption_id=<?= $app['adoption_id'] ?>" class="btn-edit">Edit</a>
                                        <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Are you sure you want to cancel this application?');">
                                            <input type="hidden" name="adoption_id" value="<?= $app['adoption_id'] ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <button type="submit" class="btn-cancel">Cancel</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 13px;">No actions available</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        // Toggle dropdown
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (userIcon && dropdown && !userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

