<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

$userId = $_SESSION['user_id'];
$errors = [];
$success = false;

// Get current user information
$user = null;
$sql = 'SELECT user_id, firstname, lastname, email, address, phone FROM users WHERE user_id = ? LIMIT 1';
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
}

if (!$user) {
    header('Location: homepage.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = trim($_POST['firstname'] ?? '');
    $lastname = trim($_POST['lastname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    // Validation
    if (empty($firstname)) {
        $errors[] = 'First name is required.';
    }
    if (empty($lastname)) {
        $errors[] = 'Last name is required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email is required.';
    }
    if (empty($address)) {
        $errors[] = 'Address is required.';
    }
    if (empty($phone)) {
        $errors[] = 'Phone number is required.';
    }
    
    // Check if email is already taken by another user
    if (empty($errors) && $email !== $user['email']) {
        $checkStmt = $conn->prepare('SELECT user_id FROM users WHERE email = ? AND user_id != ? LIMIT 1');
        if ($checkStmt) {
            $checkStmt->bind_param('si', $email, $userId);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows > 0) {
                $errors[] = 'Email is already registered by another user.';
            }
            $checkStmt->close();
        }
    }
    
    // Update user information
    if (empty($errors)) {
        $updateStmt = $conn->prepare('UPDATE users SET firstname = ?, lastname = ?, email = ?, address = ?, phone = ? WHERE user_id = ?');
        if ($updateStmt) {
            $updateStmt->bind_param('sssssi', $firstname, $lastname, $email, $address, $phone, $userId);
            if ($updateStmt->execute()) {
                $success = true;
                // Update session email if changed
                if ($email !== $user['email']) {
                    $_SESSION['user_email'] = $email;
                }
                // Update user data for display
                $user['firstname'] = $firstname;
                $user['lastname'] = $lastname;
                $user['email'] = $email;
                $user['address'] = $address;
                $user['phone'] = $phone;
            } else {
                $errors[] = 'Failed to update profile. Please try again.';
            }
            $updateStmt->close();
        } else {
            $errors[] = 'Database error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .nav-menu a.active {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 900px;
            margin: 0 auto;
        }

        .profile-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }

        .profile-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }

        .profile-header h1 {
            font-size: 32px;
            font-weight: 800;
            color: #333;
        }

        /* Messages */
        .message {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .message.error {
            background-color: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .message.success {
            background-color: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }

        /* Form */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            color: #333;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #f08080;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-save {
            background-color: #f08080;
            color: white;
        }

        .btn-save:hover {
            background-color: #e06b6b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(240, 128, 128, 0.4);
        }

        .btn-cancel {
            background-color: transparent;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-cancel:hover {
            background-color: #f5f5f5;
            border-color: #999;
        }

        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .profile-container {
                padding: 25px;
            }

            .profile-header h1 {
                font-size: 24px;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <div class="profile-container">
            <div class="profile-header">
                <h1>Edit Profile</h1>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="message error">
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="message success">
                    Profile updated successfully!
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="firstname">First Name</label>
                    <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($user['firstname']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="lastname">Last Name</label>
                    <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($user['lastname']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" value="<?= htmlspecialchars($user['address'] ?? '') ?>" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-save">
                        <i class="fas fa-save"></i>
                        Save Changes
                    </button>
                    <a href="profile.php" class="btn btn-cancel">
                        <i class="fas fa-times"></i>
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </main>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (userIcon && dropdown && !userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

