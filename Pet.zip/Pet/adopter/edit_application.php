<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

$user_id = $_SESSION['user_id'];
$adoption_id = (int)($_GET['adoption_id'] ?? 0);
$adoption = null;
$pet = null;
$errors = [];
$success = false;

// Load adoption data
if ($adoption_id > 0) {
    $stmt = $conn->prepare("SELECT a.adoption_id, a.status, a.living_situation, a.reason_adoption, a.pet_id,
                                   p.pet_id, p.name AS pet_name, p.type, p.breed, p.age, p.gender, p.image, p.status AS pet_status
                            FROM adoptions a
                            JOIN pets p ON a.pet_id = p.pet_id
                            WHERE a.adoption_id = ? AND a.adopter_id = ?");
    if ($stmt) {
        $stmt->bind_param('ii', $adoption_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $adoption = $result->fetch_assoc();
        $stmt->close();
        
        if (!$adoption) {
            header('Location: my_applications.php');
            exit;
        }
        
        // Check if status is Pending - only allow editing if pending
        if ($adoption['status'] !== 'Pending') {
            $errors[] = 'You can only edit pending applications.';
        }
        
        $pet = $adoption;
    }
} else {
    header('Location: my_applications.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    $living_situation = $_POST['livingSituation'] ?? '';
    $reason_adoption = trim($_POST['adoptionReason'] ?? '');
    
    // Validation
    if (empty($living_situation)) $errors[] = 'Living situation is required.';
    if (empty($reason_adoption)) $errors[] = 'Adoption reason is required.';
    
    // Verify again that status is still Pending (in case it changed)
    if (empty($errors)) {
        $checkStmt = $conn->prepare("SELECT status FROM adoptions WHERE adoption_id = ? AND adopter_id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param('ii', $adoption_id, $user_id);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            $currentAdoption = $checkResult->fetch_assoc();
            $checkStmt->close();
            
            if (!$currentAdoption || $currentAdoption['status'] !== 'Pending') {
                $errors[] = 'You can only edit pending applications.';
            }
        }
    }
    
    // Update application
    if (empty($errors)) {
        $updateStmt = $conn->prepare("UPDATE adoptions SET living_situation = ?, reason_adoption = ? WHERE adoption_id = ? AND adopter_id = ?");
        if ($updateStmt) {
            $updateStmt->bind_param('ssii', $living_situation, $reason_adoption, $adoption_id, $user_id);
            if ($updateStmt->execute()) {
                $success = true;
                // Reload the adoption data
                $stmt = $conn->prepare("SELECT a.adoption_id, a.status, a.living_situation, a.reason_adoption, a.pet_id,
                                               p.pet_id, p.name AS pet_name, p.type, p.breed, p.age, p.gender, p.image, p.status AS pet_status
                                        FROM adoptions a
                                        JOIN pets p ON a.pet_id = p.pet_id
                                        WHERE a.adoption_id = ? AND a.adopter_id = ?");
                if ($stmt) {
                    $stmt->bind_param('ii', $adoption_id, $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $adoption = $result->fetch_assoc();
                    $pet = $adoption;
                    $stmt->close();
                }
            } else {
                $errors[] = 'Failed to update application. Please try again.';
            }
            $updateStmt->close();
        } else {
            $errors[] = 'Database error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Application - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Page Title */
        .page-title {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 40px;
        }

        /* Pet Information Card */
        .pet-info-card {
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .pet-image-container {
            flex-shrink: 0;
        }

        .pet-image-container img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #f08080;
        }

        .pet-details {
            flex: 1;
        }

        .pet-name {
            font-size: 28px;
            font-weight: 800;
            color: #333;
            margin-bottom: 20px;
        }

        .pet-attributes {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .pet-attribute {
            display: flex;
            flex-direction: column;
        }

        .pet-attribute-label {
            font-size: 13px;
            color: #666;
            font-weight: 400;
            margin-bottom: 5px;
        }

        .pet-attribute-value {
            font-size: 15px;
            color: #333;
            font-weight: 700;
        }

        /* Form Sections */
        .form-section {
            margin-bottom: 35px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-row-full {
            grid-column: 1 / -1;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 14px;
            color: #333;
            font-weight: 500;
            margin-bottom: 8px;
        }

        /* Radio Buttons */
        .radio-group {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .radio-option input[type="radio"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .radio-option label {
            font-size: 14px;
            color: #333;
            font-weight: 400;
            cursor: pointer;
            margin: 0;
        }

        /* Textarea */
        .form-group textarea {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            resize: vertical;
            min-height: 120px;
            transition: border-color 0.3s;
        }

        .form-group textarea:focus {
            outline: none;
            border-color: #f08080;
        }

        .form-group textarea::placeholder {
            color: #999;
        }

        /* Action Buttons */
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 40px;
        }

        .btn-submit {
            background-color: #1E3A4E;
            color: white;
            border: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-submit:hover {
            background-color: #2A506E;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(30, 58, 78, 0.3);
        }

        .btn-cancel {
            background-color: white;
            color: #333;
            border: 1px solid #ddd;
            padding: 12px 40px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-block;
        }

        .btn-cancel:hover {
            background-color: #f5f5f5;
            border-color: #ccc;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .pet-info-card {
                flex-direction: column;
                text-align: center;
            }

            .pet-attributes {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn-submit,
            .btn-cancel {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon">
            <i class="fas fa-user"></i>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Page Title -->
        <h1 class="page-title">Edit Application</h1>

        <?php if ($success): ?>
        <div style="background:#e8f5e8;color:#2e7d32;border:1px solid #c8e6c9;padding:15px;border-radius:8px;margin-bottom:20px;text-align:center;">
            <h2 style="margin:0 0 10px 0;">Application Updated Successfully!</h2>
            <p style="margin:0;">Your adoption application has been updated.</p>
            <a href="my_applications.php" style="display:inline-block;margin-top:15px;color:#2e7d32;font-weight:600;">View My Applications</a>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
        <div style="background:#ffebee;color:#c62828;border:1px solid #ffcdd2;padding:15px;border-radius:8px;margin-bottom:20px;">
            <ul style="margin:0;padding-left:20px;">
                <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        
        <!-- Pet Information Card -->
        <?php if ($pet): 
            $ageText = $pet['age'] == 1 ? '1 year' : $pet['age'] . ' years';
        ?>
        <div class="pet-info-card">
            <div class="pet-image-container">
                <img src="../<?= htmlspecialchars($pet['image']) ?>" alt="<?= htmlspecialchars($pet['pet_name']) ?>">
            </div>
            <div class="pet-details">
                <h2 class="pet-name"><?= htmlspecialchars($pet['pet_name']) ?></h2>
                <div class="pet-attributes">
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Type</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['type']) ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Breed</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['breed']) ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Age</span>
                        <span class="pet-attribute-value"><?= $ageText ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Gender</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['gender']) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Application Form -->
        <?php if (!$success && $adoption && $adoption['status'] === 'Pending'): ?>
        <form id="editForm" method="POST" action="">
            <!-- Living Situation -->
            <div class="form-section">
                <h2 class="section-title">Living Situation</h2>
                <div class="radio-group">
                    <div class="radio-option">
                        <input type="radio" id="house" name="livingSituation" value="house" <?= ($adoption['living_situation'] ?? '') === 'house' ? 'checked' : '' ?>>
                        <label for="house">House</label>
                    </div>
                    <div class="radio-option">
                        <input type="radio" id="apartment" name="livingSituation" value="apartment" <?= ($adoption['living_situation'] ?? '') === 'apartment' ? 'checked' : '' ?>>
                        <label for="apartment">Apartment</label>
                    </div>
                    <div class="radio-option">
                        <input type="radio" id="other" name="livingSituation" value="other" <?= ($adoption['living_situation'] ?? '') === 'other' ? 'checked' : '' ?>>
                        <label for="other">Other</label>
                    </div>
                </div>
            </div>

            <!-- Adoption Reason -->
            <div class="form-section">
                <h2 class="section-title">Adoption Reason</h2>
                <p style="font-size: 14px; color: #666; margin-bottom: 10px;">Why do you want to adopt this pet?</p>
                <div class="form-group">
                    <textarea id="adoptionReason" name="adoptionReason" placeholder="Tell us why you'd want this pet..." required><?= htmlspecialchars($adoption['reason_adoption'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="form-actions">
                <a href="my_applications.php" class="btn-cancel">Cancel</a>
                <button type="submit" class="btn-submit">Update Application</button>
            </div>
        </form>
        <?php elseif ($adoption && $adoption['status'] !== 'Pending'): ?>
        <div style="background:#ffebee;color:#c62828;border:1px solid #ffcdd2;padding:15px;border-radius:8px;margin-bottom:20px;text-align:center;">
            <p style="margin:0;">You can only edit pending applications. This application status is: <strong><?= htmlspecialchars($adoption['status']) ?></strong></p>
            <a href="my_applications.php" style="display:inline-block;margin-top:15px;color:#c62828;font-weight:600;">Back to My Applications</a>
        </div>
        <?php endif; ?>
    </main>

    <script>
        // User icon click
        document.querySelector('.user-icon').addEventListener('click', function() {
            window.location.href = '../login.php';
        });
    </script>
</body>
</html>

