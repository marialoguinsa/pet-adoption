<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

// Get user information
$userId = $_SESSION['user_id'];
$user = null;

$sql = 'SELECT user_id, firstname, lastname, email, address, phone, created_at FROM users WHERE user_id = ? LIMIT 1';
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
}

if (!$user) {
    header('Location: homepage.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .nav-menu a.active {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 900px;
            margin: 0 auto;
        }

        .profile-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }

        .profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }

        .profile-header h1 {
            font-size: 32px;
            font-weight: 800;
            color: #333;
        }

        .btn-edit-profile {
            background-color: #f08080;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-edit-profile:hover {
            background-color: #e06b6b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(240, 128, 128, 0.4);
        }

        .profile-info {
            display: grid;
            gap: 25px;
        }

        .info-item {
            display: flex;
            flex-direction: column;
        }

        .info-label {
            font-size: 13px;
            color: #666;
            font-weight: 400;
            margin-bottom: 8px;
        }

        .info-value {
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }

        .info-value.empty {
            color: #999;
            font-style: italic;
        }

        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .profile-container {
                padding: 25px;
            }

            .profile-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .profile-header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <div class="profile-container">
            <div class="profile-header">
                <h1>My Profile</h1>
                <a href="edit_profile.php" class="btn-edit-profile">
                    <i class="fas fa-edit"></i>
                    Edit Profile
                </a>
            </div>

            <div class="profile-info">
                <div class="info-item">
                    <span class="info-label">First Name</span>
                    <span class="info-value"><?= htmlspecialchars($user['firstname']) ?></span>
                </div>

                <div class="info-item">
                    <span class="info-label">Last Name</span>
                    <span class="info-value"><?= htmlspecialchars($user['lastname']) ?></span>
                </div>

                <div class="info-item">
                    <span class="info-label">Email Address</span>
                    <span class="info-value"><?= htmlspecialchars($user['email']) ?></span>
                </div>

                <div class="info-item">
                    <span class="info-label">Phone Number</span>
                    <span class="info-value <?= empty($user['phone']) ? 'empty' : '' ?>">
                        <?= !empty($user['phone']) ? htmlspecialchars($user['phone']) : 'Not provided' ?>
                    </span>
                </div>

                <div class="info-item">
                    <span class="info-label">Address</span>
                    <span class="info-value <?= empty($user['address']) ? 'empty' : '' ?>">
                        <?= !empty($user['address']) ? htmlspecialchars($user['address']) : 'Not provided' ?>
                    </span>
                </div>

                <div class="info-item">
                    <span class="info-label">Member Since</span>
                    <span class="info-value">
                        <?= date('F j, Y', strtotime($user['created_at'])) ?>
                    </span>
                </div>
            </div>
        </div>
    </main>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (!userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

