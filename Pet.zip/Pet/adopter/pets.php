<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

// Get filter parameters
$typeFilter = $_GET['type'] ?? '';
$breedFilter = $_GET['breed'] ?? '';
$genderFilter = $_GET['gender'] ?? '';
$ageFilter = $_GET['age'] ?? '';

// Build query
$sql = "SELECT pet_id, name, type, breed, age, gender, description, image, status FROM pets WHERE status IN ('Available', 'Pending')";
$params = [];
$types = '';

if ($typeFilter && strtolower($typeFilter) !== 'all') {
    $sql .= " AND type = ?";
    $params[] = ucfirst(strtolower($typeFilter));
    $types .= 's';
}

if ($breedFilter && $breedFilter !== 'any') {
    $sql .= " AND breed LIKE ?";
    $params[] = '%' . $breedFilter . '%';
    $types .= 's';
}

if ($genderFilter && $genderFilter !== 'any') {
    $sql .= " AND gender = ?";
    $params[] = ucfirst($genderFilter);
    $types .= 's';
}

if ($ageFilter && $ageFilter !== 'any') {
    if ($ageFilter === 'puppy') {
        $sql .= " AND age <= 1";
    } elseif ($ageFilter === 'young') {
        $sql .= " AND age > 1 AND age <= 3";
    } elseif ($ageFilter === 'adult') {
        $sql .= " AND age > 3 AND age <= 7";
    } elseif ($ageFilter === 'senior') {
        $sql .= " AND age > 7";
    }
}

$sql .= " ORDER BY pet_id ASC";

$pets = [];
$stmt = $conn->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $pets[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .nav-menu a.active {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #592518;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Title Section */
        .title-section {
            text-align: center;
            margin-bottom: 40px;
        }

        .title-section h1 {
            font-size: 42px;
            font-weight: 800;
            color: #333;
            margin-bottom: 10px;
        }

        .title-section p {
            font-size: 18px;
            color: #666;
            font-weight: 400;
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .pet-type-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .pet-type-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 25px;
            border: none;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .pet-type-btn.active {
            background-color: #f08080;
            color: white;
        }

        .pet-type-btn.inactive {
            background-color: transparent;
            color: #592518;
        }

        .pet-type-btn.inactive:hover {
            color: #f08080;
        }

        .pet-type-btn i {
            font-size: 16px;
        }

        .filter-dropdowns {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .filter-dropdown {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: white;
            cursor: pointer;
            min-width: 150px;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23333' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 35px;
        }

        .filter-dropdown:focus {
            outline: none;
            border-color: #f08080;
        }

        .filter-btn {
            background-color: #f08080;
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .filter-btn:hover {
            background-color: #e06b6b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(240, 128, 128, 0.4);
        }

        /* Pet Cards Grid */
        .pets-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            margin-bottom: 40px;
        }

        .pet-card {
            background-color: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            cursor: pointer;
        }

        .pet-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .pet-card-image {
            width: 100%;
            height: 280px;
            object-fit: cover;
            display: block;
        }

        .pet-card-info {
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .pet-card-left {
            flex: 1;
        }

        .pet-card-name {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 8px;
        }

        .pet-card-action {
            font-size: 13px;
            color: #666;
            text-decoration: none;
            display: inline-block;
            transition: color 0.3s;
        }

        .pet-card-action:hover {
            color: #f08080;
        }

        .pet-card-age {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }

        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal-container {
            background-color: white;
            border-radius: 10px;
            max-width: 900px;
            width: 100%;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2001;
            transition: background-color 0.3s;
        }

        .modal-close:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }

        .modal-image-section {
            flex: 1;
            min-width: 400px;
            background-color: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            min-height: 500px;
        }

        .modal-image-section img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .modal-content-section {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .modal-pet-name {
            font-size: 28px;
            font-weight: 800;
            color: #333;
            margin-bottom: 30px;
        }

        .modal-pet-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }

        .modal-detail-item {
            display: flex;
            flex-direction: column;
        }

        .modal-detail-label {
            font-size: 13px;
            color: #666;
            font-weight: 400;
            margin-bottom: 5px;
        }

        .modal-detail-value {
            font-size: 15px;
            color: #f08080;
            font-weight: 700;
        }

        .modal-description {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .modal-adopt-btn {
            background-color: #1E3A4E;
            color: white;
            border: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
            align-self: flex-end;
            margin-top: auto;
        }

        .modal-adopt-btn:hover {
            background-color: #2A506E;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(30, 58, 78, 0.3);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .pets-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .filter-section {
                flex-direction: column;
                align-items: flex-start;
            }

            .filter-dropdowns {
                flex-wrap: wrap;
                width: 100%;
            }

            .pets-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
            }

            .title-section h1 {
                font-size: 32px;
            }

            .title-section p {
                font-size: 16px;
            }
        }

        @media (max-width: 480px) {
            .pets-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .modal-container {
                flex-direction: column;
                max-height: 95vh;
            }

            .modal-image-section {
                min-width: 100%;
                height: 250px;
            }

            .modal-content-section {
                padding: 25px;
            }

            .modal-pet-details {
                grid-template-columns: 1fr;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php" class="active">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Title Section -->
        <div class="title-section">
            <h1>Give Love, Get Love</h1>
            <p>Thousands of pets are waiting for a family like yours</p>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <div class="pet-type-buttons">
                <button class="pet-type-btn <?= ($typeFilter === '' || $typeFilter === 'all') ? 'active' : 'inactive' ?>" onclick="filterByType('all')">
                    <span>All</span>
                </button>
                <button class="pet-type-btn <?= (strtolower($typeFilter) === 'dog') ? 'active' : 'inactive' ?>" onclick="filterByType('dog')">
                    <i class="fas fa-dog"></i>
                    <span>DOGS</span>
                </button>
                <button class="pet-type-btn <?= (strtolower($typeFilter) === 'cat') ? 'active' : 'inactive' ?>" onclick="filterByType('cat')">
                    <i class="fas fa-cat"></i>
                    <span>CATS</span>
                </button>
            </div>

            <div class="filter-dropdowns">
                <select class="filter-dropdown" id="gender">
                    <option value="" disabled>Gender</option>
                    <option value="any" <?= ($genderFilter === '' || $genderFilter === 'any') ? 'selected' : '' ?>>Any</option>
                    <option value="male" <?= ($genderFilter === 'male') ? 'selected' : '' ?>>Male</option>
                    <option value="female" <?= ($genderFilter === 'female') ? 'selected' : '' ?>>Female</option>
                </select>

                <select class="filter-dropdown" id="age">
                    <option value="" disabled>Age</option>
                    <option value="any" <?= ($ageFilter === '' || $ageFilter === 'any') ? 'selected' : '' ?>>Any</option>
                    <option value="puppy" <?= ($ageFilter === 'puppy') ? 'selected' : '' ?>>Puppy (0-1 year)</option>
                    <option value="young" <?= ($ageFilter === 'young') ? 'selected' : '' ?>>Young (1-3 years)</option>
                    <option value="adult" <?= ($ageFilter === 'adult') ? 'selected' : '' ?>>Adult (3-7 years)</option>
                    <option value="senior" <?= ($ageFilter === 'senior') ? 'selected' : '' ?>>Senior (7+ years)</option>
                </select>
            </div>

            <button class="filter-btn" onclick="applyFilters()">
                Filter
            </button>
        </div>

        <!-- Pet Cards Grid -->
        <div class="pets-grid">
            <?php if (empty($pets)): ?>
                <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #666;">
                    <p style="font-size: 18px;">No pets available at the moment.</p>
                </div>
            <?php else: ?>
                <?php foreach ($pets as $pet): 
                    $ageText = $pet['age'] == 1 ? '1 year' : $pet['age'] . ' years';
                    // Get image from database
                    $dbImage = !empty($pet['image']) ? trim($pet['image']) : '';
                    
                    // Build image path - images are stored as 'pics/filename.jpg' in database
                    if (!empty($dbImage)) {
                        // Remove any leading slashes or dots
                        $cleanPath = ltrim($dbImage, './');
                        
                        // If it already starts with 'pics/', use it directly with '../' prefix
                        if (strpos($cleanPath, 'pics/') === 0) {
                            $imagePath = '../' . $cleanPath;
                        }
                        // If it doesn't start with 'pics/', add it
                        else {
                            $imagePath = '../pics/' . $cleanPath;
                        }
                        
                        // Verify file exists, otherwise use default
                        $fullPath = __DIR__ . '/../' . $cleanPath;
                        if (!file_exists($fullPath) || !is_file($fullPath)) {
                            $imagePath = '../pics/pets.jpg';
                        }
                    } else {
                        $imagePath = '../pics/pets.jpg'; // Default fallback
                    }
                ?>
                <div class="pet-card" onclick="viewPet(<?= $pet['pet_id'] ?>)">
                    <img src="<?= htmlspecialchars($imagePath) ?>" alt="<?= htmlspecialchars($pet['name']) ?>" class="pet-card-image" onerror="this.src='../pics/pets.jpg'; this.onerror=null;" style="object-fit: cover;">
                    <div class="pet-card-info">
                        <div class="pet-card-left">
                            <div class="pet-card-name"><?= htmlspecialchars($pet['name']) ?></div>
                            <a href="#" class="pet-card-action" onclick="event.stopPropagation(); openModal(<?= $pet['pet_id'] ?>, '<?= htmlspecialchars($pet['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($pet['type'], ENT_QUOTES) ?>', '<?= htmlspecialchars($pet['breed'], ENT_QUOTES) ?>', '<?= $ageText ?>', '<?= htmlspecialchars($pet['gender'], ENT_QUOTES) ?>', '<?= htmlspecialchars($pet['status'], ENT_QUOTES) ?>', '<?= htmlspecialchars($pet['description'], ENT_QUOTES) ?>', '<?= htmlspecialchars($imagePath, ENT_QUOTES) ?>'); return false;">Click Me →</a>
                        </div>
                        <div class="pet-card-age"><?= $ageText ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <!-- Modal -->
    <div class="modal-overlay" id="petModal">
        <div class="modal-container">
            <button class="modal-close" onclick="closeModal()">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-image-section">
                <img id="modalPetImage" src="../pics/pets.jpg" alt="Pet">
            </div>
            <div class="modal-content-section">
                <div>
                    <h2 class="modal-pet-name" id="modalPetName">Elias Bogart</h2>
                    <div class="modal-pet-details">
                        <div class="modal-detail-item">
                            <span class="modal-detail-label">Type</span>
                            <span class="modal-detail-value" id="modalPetType">Dog</span>
                        </div>
                        <div class="modal-detail-item">
                            <span class="modal-detail-label">Breed</span>
                            <span class="modal-detail-value" id="modalPetBreed">Golden Retriever</span>
                        </div>
                        <div class="modal-detail-item">
                            <span class="modal-detail-label">Age</span>
                            <span class="modal-detail-value" id="modalPetAge">1 year</span>
                        </div>
                        <div class="modal-detail-item">
                            <span class="modal-detail-label">Gender</span>
                            <span class="modal-detail-value" id="modalPetGender">Male</span>
                        </div>
                        <div class="modal-detail-item">
                            <span class="modal-detail-label">Status</span>
                            <span class="modal-detail-value" id="modalPetStatus">Available</span>
                        </div>
                    </div>
                    <p class="modal-description" id="modalPetDescription">Friendly, loves kids and walks.</p>
                </div>
                <button class="modal-adopt-btn" onclick="adoptPet()">Adopt Me</button>
            </div>
        </div>
    </div>

    <script>
        // Pet data storage
        let currentPetId = '';

        // Open modal function
        function openModal(petId, name, type, breed, age, gender, status, description, image) {
            currentPetId = petId;
            document.getElementById('modalPetName').textContent = name;
            document.getElementById('modalPetType').textContent = type;
            document.getElementById('modalPetBreed').textContent = breed;
            document.getElementById('modalPetAge').textContent = age;
            document.getElementById('modalPetGender').textContent = gender;
            document.getElementById('modalPetStatus').textContent = status;
            document.getElementById('modalPetDescription').textContent = description;
            document.getElementById('modalPetImage').src = image;
            document.getElementById('petModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Close modal function
        function closeModal() {
            document.getElementById('petModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        // Close modal when clicking outside
        document.getElementById('petModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Adopt pet function
        function adoptPet() {
            if (!currentPetId) {
                alert('Please select a pet first.');
                return;
            }
            // Redirect to application form with pet ID
            window.location.href = 'application_form.php?pet_id=' + currentPetId;
        }
        // Filter by pet type - automatically applies filter on click
        function filterByType(type) {
            // Get current gender and age filter values
            const gender = document.getElementById('gender').value || 'any';
            const age = document.getElementById('age').value || 'any';
            
            const params = new URLSearchParams();
            
            // Set type filter
            if (type && type.toLowerCase() !== 'all') {
                params.set('type', type.charAt(0).toUpperCase() + type.slice(1).toLowerCase());
            }
            
            // Preserve gender filter if set
            if (gender && gender !== 'any') {
                params.set('gender', gender);
            }
            
            // Preserve age filter if set
            if (age && age !== 'any') {
                params.set('age', age);
            }
            
            // Navigate with filters
            window.location.href = 'pets.php?' + params.toString();
        }

        // Apply filters - for gender and age filters
        function applyFilters() {
            const gender = document.getElementById('gender').value || 'any';
            const age = document.getElementById('age').value || 'any';
            
            // Get current type filter from active button
            const activeTypeBtn = document.querySelector('.pet-type-btn.active');
            let type = '';
            if (activeTypeBtn) {
                const btnText = activeTypeBtn.textContent.trim();
                if (btnText.includes('DOG')) {
                    type = 'Dog';
                } else if (btnText.includes('CAT')) {
                    type = 'Cat';
                }
            }
            
            const params = new URLSearchParams();
            
            // Set type filter if not "All"
            if (type) {
                params.set('type', type);
            }
            
            // Set gender filter if not "any"
            if (gender && gender !== 'any') {
                params.set('gender', gender);
            }
            
            // Set age filter if not "any"
            if (age && age !== 'any') {
                params.set('age', age);
            }
            
            // Navigate with filters
            window.location.href = 'pets.php?' + params.toString();
        }

        // View pet details
        function viewPet(petId) {
            console.log('Viewing pet:', petId);
            // Redirect to pet details page
            // window.location.href = 'pet_details.php?id=' + petId;
        }

        // Toggle dropdown
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (userIcon && dropdown && !userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

