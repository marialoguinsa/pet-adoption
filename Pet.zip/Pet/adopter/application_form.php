<?php
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../db_connection.php';

$pet_id = (int)($_GET['pet_id'] ?? 0);
$pet = null;
$errors = [];
$success = false;

if ($pet_id > 0) {
    $stmt = $conn->prepare("SELECT pet_id, name, type, breed, age, gender, description, image, status FROM pets WHERE pet_id = ?");
    if ($stmt) {
        $stmt->bind_param('i', $pet_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $pet = $result->fetch_assoc();
        $stmt->close();
        
        if (!$pet || $pet['status'] === 'Adopted') {
            header('Location: pets.php');
            exit;
        }
    }
} else {
    header('Location: pets.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = trim($_POST['firstName'] ?? '');
    $lastname = trim($_POST['lastName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $living_situation = $_POST['livingSituation'] ?? '';
    $reason_adoption = trim($_POST['adoptionReason'] ?? '');
    $application_date = $_POST['applicationDate'] ?? date('Y-m-d');
    
    // Validation
    if (empty($firstname)) $errors[] = 'First name is required.';
    if (empty($lastname)) $errors[] = 'Last name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (empty($phone)) $errors[] = 'Phone number is required.';
    if (empty($address)) $errors[] = 'Address is required.';
    if (empty($living_situation)) $errors[] = 'Living situation is required.';
    if (empty($reason_adoption)) $errors[] = 'Adoption reason is required.';
    
    // Check if user already applied for this pet
    if (empty($errors)) {
        $checkStmt = $conn->prepare("SELECT adoption_id FROM adoptions WHERE adopter_id = ? AND pet_id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param('ii', $_SESSION['user_id'], $pet_id);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows > 0) {
                $errors[] = 'You have already applied for this pet.';
            }
            $checkStmt->close();
        }
    }
    
    // Insert application
    if (empty($errors)) {
        $insertStmt = $conn->prepare("INSERT INTO adoptions (adopter_id, pet_id, living_situation, reason_adoption, status) VALUES (?, ?, ?, ?, 'Pending')");
        if ($insertStmt) {
            $insertStmt->bind_param('iiss', $_SESSION['user_id'], $pet_id, $living_situation, $reason_adoption);
            if ($insertStmt->execute()) {
                $success = true;
                // Update pet status to Pending if it was Available
                if ($pet['status'] === 'Available') {
                    $updateStmt = $conn->prepare("UPDATE pets SET status = 'Pending' WHERE pet_id = ?");
                    if ($updateStmt) {
                        $updateStmt->bind_param('i', $pet_id);
                        $updateStmt->execute();
                        $updateStmt->close();
                    }
                }
            } else {
                $errors[] = 'Failed to submit application. Please try again.';
            }
            $insertStmt->close();
        } else {
            $errors[] = 'Database error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adoption Application Form - KaagaPal</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffffff;
            min-height: 100vh;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            padding: 40px 50px;
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Page Title */
        .page-title {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 40px;
        }

        /* Pet Information Card */
        .pet-info-card {
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .pet-image-container {
            flex-shrink: 0;
        }

        .pet-image-container img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #f08080;
        }

        .pet-details {
            flex: 1;
        }

        .pet-name {
            font-size: 28px;
            font-weight: 800;
            color: #333;
            margin-bottom: 20px;
        }

        .pet-attributes {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .pet-attribute {
            display: flex;
            flex-direction: column;
        }

        .pet-attribute-label {
            font-size: 13px;
            color: #666;
            font-weight: 400;
            margin-bottom: 5px;
        }

        .pet-attribute-value {
            font-size: 15px;
            color: #333;
            font-weight: 700;
        }

        /* Form Sections */
        .form-section {
            margin-bottom: 35px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-row-full {
            grid-column: 1 / -1;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 14px;
            color: #333;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"],
        .form-group input[type="date"] {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #f08080;
        }

        .form-group input::placeholder {
            color: #999;
        }

        /* Radio Buttons */
        .radio-group {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .radio-option input[type="radio"] {
            width: 18px;
            height: 18px;
            cursor: pointer;

        }

        .radio-option label {
            font-size: 14px;
            color: #333;
            font-weight: 400;
            cursor: pointer;
            margin: 0;
        }

        /* Textarea */
        .form-group textarea {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            resize: vertical;
            min-height: 120px;
            transition: border-color 0.3s;
        }

        .form-group textarea:focus {
            outline: none;
            border-color: #f08080;
        }

        .form-group textarea::placeholder {
            color: #999;
        }

        /* Checkbox */
        .checkbox-group {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 30px;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            margin-top: 3px;
            cursor: pointer;
            flex-shrink: 0;
        }

        .checkbox-group label {
            font-size: 14px;
            color: #333;
            font-weight: 400;
            cursor: pointer;
            margin: 0;
            line-height: 1.5;
        }

        /* Action Buttons */
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 40px;
        }

        .btn-submit {
            background-color: #1E3A4E;
            color: white;
            border: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-submit:hover {
            background-color: #2A506E;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(30, 58, 78, 0.3);
        }

        .btn-cancel {
            background-color: white;
            color: #333;
            border: 1px solid #ddd;
            padding: 12px 40px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .btn-cancel:hover {
            background-color: #f5f5f5;
            border-color: #ccc;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .main-content {
                padding: 30px 20px;
            }

            .pet-info-card {
                flex-direction: column;
                text-align: center;
            }

            .pet-attributes {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn-submit,
            .btn-cancel {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Page Title -->
        <h1 class="page-title">Pet Adoption Application Form</h1>

        <?php if ($success): ?>
        <div style="background:#e8f5e8;color:#2e7d32;border:1px solid #c8e6c9;padding:15px;border-radius:8px;margin-bottom:20px;text-align:center;">
            <h2 style="margin:0 0 10px 0;">Application Submitted Successfully!</h2>
            <p style="margin:0;">Your adoption application has been received. We will review it and get back to you soon.</p>
            <a href="my_applications.php" style="display:inline-block;margin-top:15px;color:#2e7d32;font-weight:600;">View My Applications</a>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
        <div style="background:#ffebee;color:#c62828;border:1px solid #ffcdd2;padding:15px;border-radius:8px;margin-bottom:20px;">
            <ul style="margin:0;padding-left:20px;">
                <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        
        <!-- Pet Information Card -->
        <?php if ($pet): 
            $ageText = $pet['age'] == 1 ? '1 year' : $pet['age'] . ' years';
            // Build image path - images are stored as 'pics/filename.jpg' in database
            $dbImage = !empty($pet['image']) ? trim($pet['image']) : '';
            
            if (!empty($dbImage)) {
                // Remove any leading slashes or dots
                $cleanPath = ltrim($dbImage, './');
                
                // If it already starts with 'pics/', use it directly with '../' prefix
                if (strpos($cleanPath, 'pics/') === 0) {
                    $imagePath = '../' . $cleanPath;
                }
                // If it doesn't start with 'pics/', add it
                else {
                    $imagePath = '../pics/' . $cleanPath;
                }
                
                // Verify file exists, otherwise use default
                $fullPath = __DIR__ . '/../' . $cleanPath;
                if (!file_exists($fullPath) || !is_file($fullPath)) {
                    $imagePath = '../pics/pets.jpg';
                }
            } else {
                $imagePath = '../pics/pets.jpg'; // Default fallback
            }
        ?>
        <div class="pet-info-card">
            <div class="pet-image-container">
                <img src="<?= htmlspecialchars($imagePath) ?>" alt="<?= htmlspecialchars($pet['name']) ?>">
            </div>
            <div class="pet-details">
                <div class="pet-name"><?= htmlspecialchars($pet['name']) ?></div>
                <div class="pet-attributes">
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Type</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['type']) ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Breed</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['breed']) ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Age</span>
                        <span class="pet-attribute-value"><?= $ageText ?></span>
                    </div>
                    <div class="pet-attribute">
                        <span class="pet-attribute-label">Gender</span>
                        <span class="pet-attribute-value"><?= htmlspecialchars($pet['gender']) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Application Form -->
        <?php if (!$success): ?>
        <form id="adoptionForm" method="POST" action="">
            <!-- Adopter's Personal Information -->
            <div class="form-section">
                <h2 class="section-title">Adopter's Personal Information</h2>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="firstName">First Name</label>
                        <input type="text" id="firstName" name="firstName" placeholder="First Name" required value="<?= htmlspecialchars($_POST['firstName'] ?? $_SESSION['user_name'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="lastName">Last Name</label>
                        <input type="text" id="lastName" name="lastName" placeholder="Last Name" required value="<?= htmlspecialchars($_POST['lastName'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="@gmail.com" required value="<?= htmlspecialchars($_POST['email'] ?? $_SESSION['user_email'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-row form-row-full">
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" id="address" name="address" required value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="applicationDate">Date of Application</label>
                        <input type="date" id="applicationDate" name="applicationDate" required value="<?= htmlspecialchars($_POST['applicationDate'] ?? date('Y-m-d')) ?>">
                    </div>
                </div>
            </div>

            <!-- Living Situation -->
            <div class="form-section">
                <h2 class="section-title">Living Situation</h2>
                <div class="radio-group">
                    <div class="radio-option">
                        <input type="radio" id="house" name="livingSituation" value="house" checked>
                        <label for="house">House</label>
                    </div>
                    <div class="radio-option">
                        <input type="radio" id="apartment" name="livingSituation" value="apartment">
                        <label for="apartment">Apartment</label>
                    </div>
                    <div class="radio-option">
                        <input type="radio" id="other" name="livingSituation" value="other">
                        <label for="other">Other</label>
                    </div>
                </div>
            </div>

            <!-- Adoption Reason -->
            <div class="form-section">
                <h2 class="section-title">Adoption Reason</h2>
                <p style="font-size: 14px; color: #666; margin-bottom: 10px;">Why do you want to adopt this pet?</p>
                <div class="form-group">
                    <textarea id="adoptionReason" name="adoptionReason" placeholder="Tell us why you'd want this pet..." required><?= htmlspecialchars($_POST['adoptionReason'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Responsibility Checkbox -->
            <div class="checkbox-group">
                <input type="checkbox" id="responsibility" name="responsibility" required>
                <label for="responsibility">I agree to take full responsibility for the care and welfare of this pet.</label>
            </div>

            <!-- Action Buttons -->
            <div class="form-actions">
                <button type="button" class="btn-cancel" onclick="cancelApplication()">Cancel</button>
                <button type="submit" class="btn-submit">Submit</button>
            </div>
        </form>
        <?php endif; ?>
    </main>

    <script>
        // Set today's date as default
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('applicationDate').value = today;
        });

        // Form submission
        document.getElementById('adoptionForm')?.addEventListener('submit', function(e) {
            // Validate form
            const responsibility = document.getElementById('responsibility').checked;
            if (!responsibility) {
                e.preventDefault();
                alert('Please agree to take full responsibility for the pet.');
                return;
            }
            // Form will submit normally to PHP handler
        });

        // Cancel application
        function cancelApplication() {
            if (confirm('Are you sure you want to cancel this application?')) {
                window.location.href = 'pets.php';
            }
        }

        // User icon click
        // Toggle dropdown
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (userIcon && dropdown && !userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

