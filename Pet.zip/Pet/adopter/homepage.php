<?php
require_once __DIR__ . '/../auth_check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KaagaPal - Your Friend for Life</title>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('../pics/homebg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            position: relative;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: rgba(255, 255, 255, 0.95);
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-section img {
            height: 120px;
            width: auto;
            margin-top: -30px;
            margin-bottom: -20px;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
        }

        .logo-text h1 {
            font-size: 28px;
            color: #592518;
            font-weight: 800;
            margin: 0;
            line-height: 1;
        }

        .logo-text p {
            font-size: 11px;
            color: #666;
            margin: 0;
            letter-spacing: 1px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #f08080;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #592518;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .user-icon:hover {
            background-color: #654321;
        }

        .user-icon i {
            color: white;
            font-size: 20px;
        }

        /* User Dropdown */
        .user-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            min-width: 200px;
            display: none;
            z-index: 1001;
            overflow: hidden;
        }

        .user-dropdown.active {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-dropdown a:last-child {
            border-bottom: none;
        }

        .user-dropdown a:hover {
            background-color: #f5f5f5;
            color: #f08080;
        }

        .user-dropdown a i {
            margin-right: 10px;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 100px);
            padding: 50px 20px;
            position: relative;
        }

        .content-box {
            
            padding: 10px 80px;
            max-width: 850px;
            text-align: center;
            position: fixed;
            z-index: 10;
            margin-top: -200px;
        }

        .main-headline {
            font-size: 40px;
            font-weight: 800;
            color: #1E3A4E;
            margin-bottom: 15px;
            line-height: 1.2;
        }

        .sub-headline {
            font-size: 35px;
            font-weight: 800;
            color: #f08080;
            margin-bottom: 25px;
            line-height: 1.2;
        }

        .description {
            font-size: 16px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 35px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .explore-btn {
            background-color: #f08080;
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .explore-btn:hover {
            background-color: #e06b6b;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(240, 128, 128, 0.4);
        }

        .explore-btn i {
            font-size: 20px;
        }

        /* Pet Images - Framing Elements */
        .pet-frame {
            position: absolute;
            z-index: 5;
            pointer-events: none;
        }

        .pet-frame.top-left {
            top: 15%;
            left: 2%;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .pet-frame.top-right {
            top: 15%;
            right: 2%;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .pet-frame.bottom {
            bottom: 8%;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            width: 85%;
            max-width: 1200px;
        }

        .pet-frame img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid rgba(255, 255, 255, 0.8);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .pet-frame img:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);
        }

        .pet-frame.bottom img {
            width: 90px;
            height: 90px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .nav-menu {
                gap: 15px;
                font-size: 14px;
            }

            .content-box {
                padding: 40px 30px;
            }

            .main-headline {
                font-size: 32px;
            }

            .sub-headline {
                font-size: 28px;
            }

            .pet-frame img {
                width: 80px;
                height: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo-section">
            <img src="../pics/logoblue.png" alt="KaagaPal Logo">
        
        </div>
        <nav class="nav-menu">
            <a href="homepage.php">Home</a>
            <a href="#">About Us</a>
            <a href="pets.php">Pets</a>
            <a href="my_applications.php">My Adoption</a>
        </nav>
        <div class="user-icon" onclick="toggleDropdown()">
            <i class="fas fa-user"></i>
            <div class="user-dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a href="edit_profile.php"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
       
       
        <!-- Content Box -->
        <div class="content-box">
            <h1 class="main-headline">Let's find your purrefect match!</h1>
            <h2 class="sub-headline">A Home for Every Paw</h2>
            <p class="description">
                Welcome to KaagaPal, where tails wag and hearts connect. We're dedicated to matching loving families with their perfect furry companions. Browse our adorable pets and start your journey to give a forever home.
            </p>
            <a href="pets.php" class="explore-btn">
                <i class="fas fa-paw"></i>
                <span>Explore Pets</span>
            </a>
        </div>

    </main>

    <script>
        // Toggle dropdown
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userIcon = document.querySelector('.user-icon');
            const dropdown = document.getElementById('userDropdown');
            if (userIcon && dropdown && !userIcon.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

