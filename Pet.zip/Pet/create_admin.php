<?php
// One-time script to create admin account
// Run this once, then delete or protect this file

require_once __DIR__ . '/db_connection.php';

// Admin account details
$firstname = 'KaagaPal';
$lastname = 'Admin';
$email = 'admin@kaagapal.com';
$password = 'admin@2025'; // Will be hashed
$role = 'admin';

// Check if admin already exists
$checkSql = "SELECT user_id FROM users WHERE email = ? LIMIT 1";
$checkStmt = $conn->prepare($checkSql);
if ($checkStmt) {
    $checkStmt->bind_param('s', $email);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "<h2>Admin account already exists!</h2>";
        echo "<p>Email: <strong>$email</strong> is already registered.</p>";
        echo "<p>You can use this account to log in.</p>";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        
        // Insert admin using prepared statement (secure)
        $insertSql = "INSERT INTO users (firstname, lastname, email, password, role) 
                      VALUES (?, ?, ?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        
        if ($insertStmt) {
            $insertStmt->bind_param('sssss', $firstname, $lastname, $email, $hashedPassword, $role);
            
            if ($insertStmt->execute()) {
                echo "<h2 style='color: green;'>✓ Admin account successfully created!</h2>";
                echo "<p><strong>Email:</strong> $email</p>";
                echo "<p><strong>Password:</strong> $password</p>";
                echo "<p><strong>Role:</strong> $role</p>";
                echo "<p style='margin-top: 20px;'><a href='login.php'>Go to Login Page</a></p>";
            } else {
                echo "<h2 style='color: red;'>Error creating admin account:</h2>";
                echo "<p>" . htmlspecialchars($insertStmt->error) . "</p>";
            }
            $insertStmt->close();
        } else {
            echo "<h2 style='color: red;'>Error preparing statement:</h2>";
            echo "<p>" . htmlspecialchars($conn->error) . "</p>";
        }
    }
    $checkStmt->close();
} else {
    echo "<h2 style='color: red;'>Error preparing check statement:</h2>";
    echo "<p>" . htmlspecialchars($conn->error) . "</p>";
}

$conn->close();
?>

