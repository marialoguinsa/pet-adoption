<?php
session_start();
require_once __DIR__ . '/db_connection.php';

$errors = [];
$successMessage = '';

// Preserve previously entered values
$formData = [
    'firstname' => '',
    'lastname' => '',
    'email' => '',
    'address' => '',
    'phone' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['firstname'] = trim($_POST['firstname'] ?? '');
    $formData['lastname']  = trim($_POST['lastname'] ?? '');
    $formData['email']     = trim($_POST['email'] ?? '');
    $formData['address']   = trim($_POST['address'] ?? '');
    $formData['phone']     = trim($_POST['phone'] ?? '');
    $password              = $_POST['password'] ?? '';
    $confirmPassword       = $_POST['confirm_password'] ?? '';

    // Basic validation
    if ($formData['firstname'] === '') { $errors[] = 'First name is required.'; }
    if ($formData['lastname'] === '')  { $errors[] = 'Last name is required.'; }
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Valid email is required.'; }
    if ($formData['address'] === '')   { $errors[] = 'Address is required.'; }
    if ($formData['phone'] === '')     { $errors[] = 'Contact is required.'; }
    if (strlen($password) < 8)         { $errors[] = 'Password must be at least 8 characters.'; }
    if (!preg_match('/[0-9]/', $password)) { $errors[] = 'Password must contain at least one number.'; }
    if ($password !== $confirmPassword){ $errors[] = 'Passwords do not match.'; }

    if (!$errors) {
        // Check if email exists
        $sql = 'SELECT user_id FROM users WHERE email = ? LIMIT 1';
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('s', $formData['email']);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $errors[] = 'Email already registered.';
            }
            $stmt->close();
        } else {
            $errors[] = 'Failed to prepare query.';
        }
    }

    if (!$errors) {
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $insert = 'INSERT INTO users (firstname, lastname, email, address, phone, password, role) VALUES (?,?,?,?,?,?,\'adopter\')';
        $stmt = $conn->prepare($insert);
        if ($stmt) {
            $stmt->bind_param(
                'ssssss',
                $formData['firstname'],
                $formData['lastname'],
                $formData['email'],
                $formData['address'],
                $formData['phone'],
                $hashed
            );
            if ($stmt->execute()) {
                // Set success message in session for login page
                $_SESSION['signup_success'] = 'Account created successfully! Please log in with your credentials.';
                // Redirect to login page
                header('Location: login.php');
                exit;
            } else {
                $errors[] = 'Failed to create account: ' . htmlspecialchars($stmt->error);
            }
            $stmt->close();
        } else {
            $errors[] = 'Database error: ' . htmlspecialchars($conn->error);
        }
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>

     <div class="main-section">
           
        <div class="top-section">
        <img src="pics/logoblue.png" alt="KaagaPal Logo" class="logo">
        </div>
     
            <div class="left">
               <img src="pics/modeldog.jpg" alt="Dog" class="modeldog">
            </div>
           
            <div class="right">
                         <div class="sign-header">  
                             <h1>Every tail deserves a tale,<br>A Home for Every Paw</h1>
                         </div>
                         <div class="form-contents">
                         <?php if (!empty($errors)): ?>
                         <div class="validation-message error" style="display:block; margin-bottom: 15px; padding: 12px;">
                             <strong>Error:</strong> <?= htmlspecialchars(implode(' ', $errors)) ?>
                         </div>
                         <?php endif; ?>
                         <?php if ($successMessage): ?>
                         <div class="validation-message success" style="display:block; margin-bottom: 15px; padding: 12px; text-align: center;">
                             <strong style="font-size: 16px;">✓ Success!</strong><br>
                             <?= htmlspecialchars($successMessage) ?><br>
                             <a href="login.php" style="color: #388e3c; font-weight: bold; text-decoration: underline; margin-top: 10px; display: inline-block;">Click here to log in</a>
                         </div>
                         <?php endif; ?>
                         <?php if (!$successMessage): ?>
                         <form id="signupForm" method="post" action="">
                            <div class="names">
                            <input type="text" id="firstName" name="firstname" placeholder="First Name*" required value="<?= htmlspecialchars($formData['firstname']) ?>">
                            <input type="text" id="lastName" name="lastname" placeholder="Last Name*" required value="<?= htmlspecialchars($formData['lastname']) ?>">
                            </div>
                            <input type="email" name="email" placeholder="Email*" required value="<?= htmlspecialchars($formData['email']) ?>">
                            <input type="text" name="address" placeholder="Address*" required value="<?= htmlspecialchars($formData['address']) ?>">
                            <input type="tel" id="phone" name="phone" placeholder="Contact*" required value="<?= htmlspecialchars($formData['phone']) ?>">
                            <div id="phoneError" class="validation-message error" style="display: none;"></div>
                            <div class="password-wrapper">
                                <input type="password" id="password" name="password" placeholder="Password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div id="passwordStrength" class="password-strength"></div>
                            <div id="passwordRequirements" class="password-requirements">
                                <ul>
                                    <li id="length">At least 8 characters</li>
                                    <li id="uppercase">At least one uppercase letter</li>
                                    <li id="number">At least one number</li>
                                    <li id="special">At least one special character</li>
                                </ul>
                            </div>
                            
                            <div class="password-wrapper">
                                <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('confirmPassword', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div id="confirmPasswordError" class="validation-message error" style="display: none;"></div>
                            <p class="terms">
                            By signing up, you are creating a KaagaPal account and<br>
                            you agree to our Terms & Conditions and Privacy Policy
                            </p>
                            <button type="submit" class="signup-btn">Sign up</button>
                            <p class="login-link">Already have an account? <a href="login.php">Log in</a></p>
                          </form>
                          <?php endif; ?>
                         </div>
                </div>
   </div>

</body>
<script src="script.js"></script>
</html>

