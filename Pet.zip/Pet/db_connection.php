<?php
// Basic MySQLi connection helper. Include this file where DB is needed.
// Exposes $conn (mysqli) and stops execution on fatal connection error.

$servername = "localhost";
$username = "root";
$password = "";
$database = "kaagapal";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Database connection failed: " . htmlspecialchars($conn->connect_error));
}

// Ensure UTF-8 for proper encoding support
$conn->set_charset('utf8mb4');
?>
