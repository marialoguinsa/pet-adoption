// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get form elements
    const passwordField = document.getElementById('password');
    const confirmPasswordField = document.getElementById('confirmPassword');
    const phoneField = document.getElementById('phone');
    const firstNameField = document.getElementById('firstName');
    const lastNameField = document.getElementById('lastName');
    const passwordRequirements = document.getElementById('passwordRequirements');
    const passwordStrength = document.getElementById('passwordStrength');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const phoneError = document.getElementById('phoneError');

    // Check if elements exist (they might not exist if form is not displayed)
    if (!passwordField || !confirmPasswordField || !phoneField) {
        return;
    }

    // Restrict phone input to numbers and phone special characters only
    phoneField.addEventListener('input', function(e) {
        const value = e.target.value;
        const validChars = /[^0-9+\-() ]/g;
        
        if (validChars.test(value)) {
            e.target.value = value.replace(validChars, '');
            phoneError.textContent = 'Only numbers and phone symbols (+, -, (), space) allowed';
            phoneError.style.display = 'block';
        } else {
            phoneError.style.display = 'none';
        }
    });

    // Password validation
    function validatePassword(password) {
        return {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)
        };
    }

    // Password strength checker
    function checkPasswordStrength(password) {
        if (password.length === 0) {
            return { strength: '', text: '' };
        }
        
        let score = 0;
        const requirements = validatePassword(password);
        
        if (requirements.length) score++;
        if (requirements.uppercase) score++;
        if (requirements.number) score++;
        if (requirements.special) score++;
        if (password.length >= 12) score++;
        
        if (score <= 2) {
            return { strength: 'weak', text: 'Weak Password' };
        } else if (score === 3 || score === 4) {
            return { strength: 'medium', text: 'Medium Password' };
        } else {
            return { strength: 'strong', text: 'Strong Password' };
        }
    }

    function updatePasswordRequirements() {
        const password = passwordField.value;
        const requirements = validatePassword(password);
        const strength = checkPasswordStrength(password);
        
        // Update requirement indicators
        const lengthEl = document.getElementById('length');
        const uppercaseEl = document.getElementById('uppercase');
        const numberEl = document.getElementById('number');
        const specialEl = document.getElementById('special');
        
        if (lengthEl) lengthEl.className = requirements.length ? 'requirement-met' : 'requirement-not-met';
        if (uppercaseEl) uppercaseEl.className = requirements.uppercase ? 'requirement-met' : 'requirement-not-met';
        if (numberEl) numberEl.className = requirements.number ? 'requirement-met' : 'requirement-not-met';
        if (specialEl) specialEl.className = requirements.special ? 'requirement-met' : 'requirement-not-met';
        
        // Update strength indicator
        if (password.length > 0) {
            passwordStrength.textContent = strength.text;
            passwordStrength.className = 'password-strength ' + strength.strength;
            passwordStrength.style.display = 'block';
        } else {
            passwordStrength.style.display = 'none';
        }
    }

    // Password events
    passwordField.addEventListener('focus', () => passwordRequirements.style.display = 'block');
    passwordField.addEventListener('blur', () => {
        if (passwordField.value.length === 0) {
            passwordRequirements.style.display = 'none';
            passwordStrength.style.display = 'none';
        }
    });
    passwordField.addEventListener('input', () => {
        updatePasswordRequirements();
        if (confirmPasswordField.value) validateConfirmPassword();
    });

    // Confirm password validation
    function validateConfirmPassword() {
        const match = passwordField.value === confirmPasswordField.value;
        if (!confirmPasswordField.value) {
            confirmPasswordError.style.display = 'none';
        } else if (match) {
            confirmPasswordError.textContent = 'Passwords match';
            confirmPasswordError.className = 'validation-message success';
            confirmPasswordError.style.display = 'block';
        } else {
            confirmPasswordError.textContent = 'Passwords do not match';
            confirmPasswordError.className = 'validation-message error';
            confirmPasswordError.style.display = 'block';
        }
    }

    confirmPasswordField.addEventListener('input', validateConfirmPassword);
});

// Password toggle function for show/hide password
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input && icon) {
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
}

